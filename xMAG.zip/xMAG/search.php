 <!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
    <title>Rezultatele căutării</title>
    <link rel = "icon" href ="img/xmag_icon.png" type = "image/x-icon">
    <style>
    *{
        font-family: Bahnschrift;
    }

    body {
        background-color: #EFFFFF;
    }

    #cont {
        min-height : 515px;
    }
    </style>
</head>
<body>
    <?php include 'partials/_dbconnect.php';?>
    <?php require 'partials/_nav.php' ?>

    <div class="container my-3">
        <h2 class="py-2"><b>Rezultatele căutării pentru <em>"<?php echo $_GET['search']?>"</em> :</b></h2>
        <h3><span id="cat" class="py-2"></span></h3>
        <div class="row">
        <?php 
            $noResult = true;
            $query = $_GET["search"];
            $sql = "SELECT * FROM `categories` WHERE MATCH(categorieName, categorieDesc) against('$query')";
 
            $result = mysqli_query($conn, $sql);
            while($row = mysqli_fetch_assoc($result)){
                ?><script> document.getElementById("cat").innerHTML = "Categorie: ";</script> <?php 
                $noResult = false;
                $catId = $row['categorieId'];
                $catname = $row['categorieName'];
                $catdesc = $row['categorieDesc'];
                
                echo '<div class="col-xs-3 col-sm-4 col-md-4">
                  <div class="card" style="width: 22rem; height: 26rem;">
                    <a href="viewPhoneList.php?catid=' . $catId . '"><img src="img/card-'.$catId. '.jpg" class="card-img-top" alt="Imagine pentru categorie" width="500px" height="150px"></a>
                    <div class="card-body">
                      <h5 class="card-title"><b><a href="viewPhoneList.php?catid=' . $catId . '">' . $catname . '</a></b></h5>
                      <p class="card-text" align="justify">' . $catdesc . ' </p>
                      <a href="viewPhoneList.php?catid=' . $catId . '" class="btn btn-primary" style="position: absolute; display: inline; font-size: 20px; padding: 3px 115px; bottom: 10px;">Ofertă <i class="fas fa-share-square"></i></a>
                    </div>
                  </div>
                  <h5><em>&emsp;</em></h5> 
                </div>';
        }
        ?>
        </div>
    </div>

    <div class="container my-3" id="cont">
        <h3><span id="iteam" class="py-2"></span></h3>
        <div class="row">
        <?php 
            $query = $_GET["search"];
            $sql = "SELECT * FROM `phone` WHERE MATCH(phoneName, phoneModel) against('$query')"; 
            $result = mysqli_query($conn, $sql);
            while($row = mysqli_fetch_assoc($result)){
                ?><script> document.getElementById("iteam").innerHTML = "Produse: ";</script> <?php
                $noResult = false;
                $phoneId = $row['phoneId'];
                $phoneStock = $row['phoneStock'];
                $phoneName = $row['phoneName'];
                $phonePrice = $row['phonePrice'];
                $phoneModel = $row['phoneModel'];
				$phoneSIM = $row['phoneSIM'];
				$phoneDisplay = $row['phoneDisplay'];
				$phoneDisplayRes = $row['phoneDisplayRes'];
				$phoneStorage = $row['phoneStorage'];
				$phoneStorageRAM = $row['phoneStorageRAM'];
				$phoneCPUType = $row['phoneCPUType'];
				$phoneCPU = $row['phoneCPU'];
				$phoneCPUHz = $row['phoneCPUHz'];
				$phoneCameraPrincip = $row['phoneCameraPrincip'];
				$phoneCameraRes = $row['phoneCameraRes'];
				$phoneCameraSelfie = $row['phoneCameraSelfie'];
				$phoneBatteryFC = $row['phoneBatteryFC'];
				$phoneBatteryWC = $row['phoneBatteryWC'];
				$phoneBatteryCap = $row['phoneBatteryCap'];
				$phoneOther = $row['phoneOther'];
				$phoneOtherColor = $row['phoneOtherColor'];
				$phoneOtherWeight = $row['phoneOtherWeight'];
				$phoneQuaranty = $row['phoneQuaranty'];
                $phoneCategorieId = $row['phoneCategorieId'];
                
                if($phoneStock == 0) {
                    echo '<div class="col-xs-3 col-sm-3 col-md-3">
                        <div class="card" style="width: 17.2rem; height: 38rem;">
                                <div class="card" style="background-color:  #171427; color: white;" <strong><b>&#8193 SMARTPHONE </b></strong></div>
                                <a href="viewPhone.php?phoneid=' . $phoneId . '"><img src="img/phone-'.$phoneId. '.jpg" class="card-img-top" alt="Imagine pentru produs" style="object-fit: contain; width:100%; padding: 5px 30px; height:100%;"></a> 
                            <div class="card-body">
                                <a href="viewPhone.php?phoneid=' . $phoneId . '"><h5 class="card-title" style="color: #141d28"><strong>' . $phoneName . '</strong></h5></a> 
                                <h3 style="color: #1bbca3"><strong> '.$phonePrice. ' RON</strong></h3>
                                <h6 style="color: #ff0000"><b><i class="fas fa-store-slash"></i> Stoc epuizat</b></h6> 
                                <div class="row justify-content-center">';

                        echo '</form>                            
                        <button disabled class="btn btn-primary mx-2" style="position: absolute; font-size: 20px; padding: 3px 25px; bottom: 10px;" data-toggle="modal" data-target="#loginModal">Disponibil în curând  <i class="fas fa-stopwatch"></i></button>
                            </div>
                        </div>
                    </div>
                    <h5><em>&emsp;</em></h5> 
                </div>';
                }

                else {

                echo '<div class="col-xs-3 col-sm-3 col-md-3">
                        <div class="card" style="width: 17.2rem; height: 38rem;">
                                <div class="card" style="background-color:  #171427; color: white;" <strong><b>&#8193 SMARTPHONE </b></strong></div>
                                <a href="viewPhone.php?phoneid=' . $phoneId . '"><img src="img/phone-'.$phoneId. '.jpg" class="card-img-top" alt="Imagine pentru produs" style="object-fit: contain; width:100%; padding: 5px 30px; height:100%;"></a> 
                            <div class="card-body">
                                <a href="viewPhone.php?phoneid=' . $phoneId . '"><h5 class="card-title" style="color: #141d28"><strong>' . $phoneName . '</strong></h5></a> 
                                <h3 style="color: #1bbca3"><strong> '.$phonePrice. ' RON</strong></h3>
                                <h6 style="color: #4CBB17"><b><i class="fas fa-store"></i> În stoc</b></h6> 
                                <div class="row justify-content">';
                

                                if($loggedin){
                                    $quaSql = "SELECT `itemQuantity` FROM `viewcart` WHERE phoneId = '$phoneId' AND `userId`='$userId'";
                                    $quaresult = mysqli_query($conn, $quaSql);
                                    $quaExistRows = mysqli_num_rows($quaresult);
                                    if($quaExistRows == 0) {
                                        echo '<form action="partials/_manageCart.php" method="POST">
                                              <input type="hidden" name="itemId" value="'.$phoneId. '">
                                              <button type="submit" name="addToCart" class="btn btn-primary mx-2" style="position: absolute; font-size: 20px; padding: 3px 50px; bottom: 10px;">Adaugă în coș <i class="fas fa-shopping-bag"></i></button>';
                                    }else {
                                        echo '<a href="viewCart.php"><button class="btn btn-primary mx-2" style="position: absolute; font-size: 20px; padding: 3px 65px; bottom: 10px;">Vezi coșul <i class="fas fa-shopping-basket"></i></button></a>';
                                    }
                                }
                                else{
                                    echo '<button class="btn btn-primary mx-2" style="position: absolute; font-size: 20px; padding: 3px 50px; bottom: 10px;" data-toggle="modal" data-target="#loginModal">Adaugă în coș <i class="fas fa-shopping-bag"></i></button>';
                                }
                            echo '</form>                            
                                </div>
                            </div>
                        </div>
                        <h5><em>&emsp;</em></h5> 
                    </div>';
                            }
            }
            if($noResult) {
                echo '<div class="jumbotron jumbotron-fluid">
                    <div class="container">
                        <h1><b>Pentru căutarea <em>"' .$_GET['search']. '"</em> nu a fost găsit niciun rezultat!</b></h1>
                        <p class="lead"> Sugestii: <ul>
                            <li>Asigură-te că toate literele au fost scrise corect.</li>
                            <li>Încearcă alte combinații de litere.</li>
                            <li>Încearcă alte cuvinte generale.</li></ul>
                        </p>
                    </div>
                </div> ';
            }
        ?>
        </div>
    </div>

    <?php require 'partials/_footer.php' ?>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <script src="https://unpkg.com/bootstrap-show-password@1.2.1/dist/bootstrap-show-password.min.js"></script>
</body>
</html>
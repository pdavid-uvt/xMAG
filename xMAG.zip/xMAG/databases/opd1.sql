-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `opd`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `categorieId` int(12) NOT NULL,
  `categorieName` varchar(255) NOT NULL,
  `categorieDesc` text NOT NULL,
  `categorieCreateDate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`categorieId`, `categorieName`, `categorieDesc`, `categorieCreateDate`) VALUES
(10, 'Samsung', 'Având în spate 10 ani de pionierat și de premiere în domeniu, Galaxy iți aduce următoarea generație de inovații mobile. Următoarea generație de telefoane Galaxy este aici.', '2022-12-12 16:01:20'),
(11, 'Apple', 'Descoperă universul inovator Apple. Cumpără iPhone, iPad, Apple Watch și Mac. Explorează accesoriile, divertismentul și asistența profesională.', '2022-12-12 16:02:49'),
(12, 'Huawei', 'HUAWEI funcționează perfect pentru a crea o viață frumos conectată pentru noi toți. Rapid, sigur și pe măsura așteptărilor. Descoperă produsele noastre de top.', '2022-12-12 16:04:11'),
(13, 'Xiaomi', 'Mi are în prezent numeroase produse în portofoliu, iar oferta este completată în mod constant cu cele mai noi articole Xiaomi, începând cu mai multe produse bugetare și terminând cu produse premium emblematice.', '2022-12-12 16:06:28'),
(14, 'Poco', 'Pocophone este o linie de smartphone-uri de gamă mid-range Xiaomi care duce experiența de joc la nivelul următor. Descoperă produsele noastre de top la preț avantajos. ', '2022-12-12 16:09:42'),
(15, 'Realme', 'Pe lângă propriul brand, Realme are o mulțime de oferte la smartphone-uri pe gustul tuturor. Descoperă noile oferte la produsele mid-range aflate în stoc. ', '2022-12-12 16:11:39'),
(16, 'Oppo', 'Explorează universul inovativ OPPO urmărind cele mai bune promoții pentru produsele noastre uimitoare. Oferte acum pentru smartphone-uri mid-range și high-end.', '2022-12-12 16:12:52'),
(17, 'Nokia', 'Indiferent dacă ești expert în tehnologie sau preferi lucrurile necomplicate, găsește astăzi un telefon Nokia pentru tine. Explorează telefoanele Nokia ...', '2022-12-12 16:14:02');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `contactId` int(21) NOT NULL,
  `userId` int(21) NOT NULL,
  `email` varchar(35) NOT NULL,
  `phoneNo` bigint(21) NOT NULL,
  `orderId` int(21) NOT NULL DEFAULT 0 COMMENT 'If problem is not related to the order then order id = 0',
  `message` text NOT NULL,
  `time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `contactreply`
--

CREATE TABLE `contactreply` (
  `id` int(21) NOT NULL,
  `contactId` int(21) NOT NULL,
  `userId` int(23) NOT NULL,
  `message` text NOT NULL,
  `datetime` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `deliverydetails`
--

CREATE TABLE `deliverydetails` (
  `id` int(21) NOT NULL,
  `orderId` int(21) NOT NULL,
  `deliveryBoyName` varchar(35) NOT NULL,
  `deliveryBoyphoneNo` bigint(25) NOT NULL,
  `deliveryTime` int(200) NOT NULL COMMENT 'Time in minutes',
  `dateTime` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `orderitems`
--

CREATE TABLE `orderitems` (
  `id` int(21) NOT NULL,
  `orderId` int(21) NOT NULL,
  `phoneId` int(21) NOT NULL,
  `itemQuantity` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `orderId` int(21) NOT NULL,
  `userId` int(21) NOT NULL,
  `address` varchar(255) NOT NULL,
  `zipCode` int(21) NOT NULL,
  `phoneNo` bigint(21) NOT NULL,
  `amount` int(200) NOT NULL,
  `paymentMode` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=cash on delivery, \r\n1=online ',
  `orderStatus` enum('0','1','2','3','4','5','6') NOT NULL DEFAULT '0' COMMENT '0=Order Placed.\r\n1=Order Confirmed.\r\n2=Preparing your Order.\r\n3=Your order is on the way!\r\n4=Order Delivered.\r\n5=Order Denied.\r\n6=Order Cancelled.',
  `orderDate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `phone`
--

CREATE TABLE `phone` (
  `phoneId` int(12) NOT NULL,
  `phoneStock` enum('0','1') NOT NULL DEFAULT '1' COMMENT '0=stockOUT\r\n1=stockIN',
  `phoneName` varchar(255) NOT NULL,
  `phonePrice` int (12) NOT NULL,
  `phoneModel` text NOT NULL,
  `phoneSIM` text NOT NULL,
  `phoneDisplay` text NOT NULL,
  `phoneDisplayRes` text NOT NULL,
  `phoneStorage` text NOT NULL,
  `phoneStorageRAM` text NOT NULL,
  `phoneCPUType` text NOT NULL,
  `phoneCPU` text NOT NULL,
  `phoneCPUHz` text NOT NULL,
  `phoneCameraPrincip` text NOT NULL,
  `phoneCameraRes` text NOT NULL,
  `phoneCameraSelfie` text NOT NULL,
  `phoneBatteryFC` text NOT NULL,
  `phoneBatteryWC` text NOT NULL,
  `phoneBatteryCap` text NOT NULL,
  `phoneOther` text NOT NULL,
  `phoneOtherColor` text NOT NULL,
  `phoneOtherWeight` text NOT NULL,
  `phoneQuaranty` text NOT NULL,
  `phoneCategorieId` int(12) NOT NULL,
  `phonePubDate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `phone`
--

INSERT INTO `phone` (`phoneId`, `phoneStock`, `phoneName`, `phonePrice`, `phoneModel`,`phoneSIM`,`phoneDisplay`,`phoneDisplayRes`,`phoneStorage`, `phoneStorageRAM`, `phoneCPUType`,`phoneCPU`,`phoneCPUHz`,`phoneCameraPrincip`,`phoneCameraRes`,`phoneCameraSelfie`,`phoneBatteryFC`,`phoneBatteryWC`,`phoneBatteryCap`,`phoneOther`,`phoneOtherColor`,`phoneOtherWeight`,`phoneQuaranty`,`phoneCategorieId`, `phonePubDate`) VALUES
(100, '1', 'Telefon SAMSUNG Galaxy A53 5G, 128GB, 6GB RAM, Dual SIM, Awesome Black', 1599, 'GALAXY A53','Dual SIM','6.5','1080 x 2400','128', '6', 'Octa Core', 'Exynos 850 (S.LSI 850 Nacho)', '2.4, 2', 'Cvadrupla', '64MP f1.8 + 12MP f2.4 + 5MP f2.4 + 5MP f2.4 OIS AF', '32MP f2.2', 'Da', 'Nu', 5000, 'Cablu incarcare. Nu contine adaptor priza!', 'Negru', '189', '24', 10, '2022-12-12 21:44:12'),
(101, '1', 'Telefon SAMSUNG Galaxy A13, 32GB, 3GB RAM, Dual SIM, Black', 699, 'GALAXY A13 2022','Dual SIM','6.6','2408 x 1080','32', '3', 'Octa Core', 'MediaTek | MT6769V/CTZA 64bit', '2GHz, 1.8GHz', 'Cvadrupla', '50MP f1.8 + 5MP (Ultra-Wide Angle) f2.2, FOV 123 + 2MP (Macro) f2.4 + 2MP (Depth) f2.4', '8MP f2.2', 'Nu', 'Nu', '5000', 'Cablu incarcare. Nu contine adaptor priza!', 'Negru', '195', '24', 10, '2022-12-12 21:46:01'),
(102, '1', 'Telefon SAMSUNG Galaxy A04s, 32GB, 3GB RAM, Dual SIM, Black', 568, 'GALAXY A04S','Dual SIM','6.5','720 x 1600','32', '3', 'Octa Core', '-', '2.0', 'Tripla', '50MP f1.8 + 2MP f2.4 + 2MP f2.4', '5MP F2.2', 'Da', 'Nu', '5000', 'Cablu incarcare. Nu contine adaptor priza!', 'Negru', '195', '24', 10, '2022-12-12 21:47:22'),
(103, '1', 'Telefon SAMSUNG Galaxy A13, 32GB, 3GB RAM, Dual SIM, Blue', 699, 'GALAXY A13 2022','Dual SIM','6.6','2408 x 1080','32', '3', 'Octa Core', 'MediaTek | MT6769V/CTZA 64bit', '2GHz, 1.8GHz', 'Cvadrupla', '50MP f1.8 + 5MP (Ultra-Wide Angle) f2.2, FOV 123 + 2MP (Macro) f2.4 + 2MP (Depth) f2.4', '8MP f2.2', 'Nu', 'Nu', '5000', 'Cablu incarcare. Nu contine adaptor priza!', 'Albastru', '195', '24', 10, '2022-12-12 21:49:21'),
(104, '1', 'Telefon SAMSUNG Galaxy A33 5G, 128GB, 6GB RAM, Dual SIM, Awesome Black', 1329, 'GALAXY A33','Dual SIM','6.4','1080 x 2400','128', '6', 'Octa Core', '-', '2.4, 2.0', 'Cvadrupla', '48MP f1.8 + 8MP f2.2 + 5MP f2.4 + 2MP f2.4 AF OIS', '13MP f2.2', 'Da', 'Nu', '5000', 'Cablu incarcare. Nu contine adaptor priza!', 'Negru', '186', '24', 10, '2022-12-12 21:53:21'),
(105, '1', 'Telefon SAMSUNG Galaxy A23 5G, 64GB, 4GB RAM, Dual SIM, Black', 1099, 'GALAXY A23 5G','Dual SIM','6.6','2408 x 1080','64', '4', 'Octa Core', 'Snapdragon 695', '2.2, 1.8', 'Cvadrupla', '50MP f1.8 OIS + 5MP (Ultra Wide) f2.2, FOV 123 + 2MP (Macro) f2.4 + 2MP (Depth) f2.4', '8MP f2.2', 'Da', 'Nu', '5000', 'Cablu incarcare. Nu contine adaptor priza!', 'Negru', '197', '24', 10, '2022-12-12 21:53:14'),
(106, '1', 'Telefon SAMSUNG Galaxy A04s, 32GB, 3GB RAM, Dual SIM, Green', 599, 'GALAXY A04S','Dual SIM','6.5','720 x 1600','32', '3', 'Octa Core', '-', '2.0', 'Tripla', '50MP f1.8 + 2MP f2.4 + 2MP f2.4', '5MP F2.2', 'Nu', 'Nu', '5000', 'Cablu incarcare. Nu contine adaptor priza!', 'Verde', '195', '24', 10, '2022-12-12 21:55:11'),
(107, '1', 'Telefon SAMSUNG Galaxy S22 5G, 128GB, 8GB, RAM, Dual SIM, Phantom Black', 3049, 'GALAXY S22','Dual SIM','6.1','2340 x 1080','128', '8', 'Octa Core', 'Exynos 2200 (4nm)', '2.8GHz, 2.5GHz, 1.8GHz', 'Tripla', '12MP (Ultra-Wide Angle) f2.2, FF, FOV 120°, 1/2.55”, 1.4µm + 50MP (Wide) f1.8, Dual Pixel AF, OIS, FOV 85°, 1/1.56”, 1.0µm, Adaptive Pixel + 10MP (Tele) f2.4, Zoom 3x, PD AF, OIS, FOV 36°, 1/3.94”, 1.0µm', '10MP (Wide) f2.2, Dual Pixel AF, FOV 80°, 1/3.24”, 1.22µm', 'Da', 'Da', '3700', 'Cablu incarcare. Nu contine adaptor priza!', 'Negru', '167', '24', 10, '2022-12-12 21:57:30'),
(108, '1', 'Telefon SAMSUNG Galaxy A53 5G, 128GB, 6GB RAM, Dual SIM, Awesome Blue', 1599, 'GALAXY A53','Dual SIM','6.5','1080 x 2400','128', '6', 'Octa Core', ' ', '2.4, 2', 'Cvadrupla', '64MP f1.8 + 12MP f2.4 + 5MP f2.4 + 5MP f2.4 OIS AF', '32MP f2.2', 'Da', 'Nu', '5000', 'Cablu incarcare. Nu contine adaptor priza!', '32MP f2.2', '189', '24', 10, '2022-12-12 21:59:56'),
(109, '1', 'Telefon SAMSUNG Galaxy S20 Fan Edition 5G, 128GB, 6GB RAM, Dual SIM, Cloud Navy', 2182, 'GALAXY S20 FAN EDITION','Dual SIM','6.5','1080 x 2400','128', '6', 'Octa Core', 'Qualcomm SDR865', '2.8GHz, 2.4GHz, 1.8GHz', 'Tripla', '12MP (Wide) F1.8 + 8MP (Telephoto) f2.0, Zoom 3x + 12MP (Ultra-Wide) f2.2', '32MP, f2.0', 'Da', 'Da', '4500', 'Cablu incarcare. Nu contine adaptor priza!', 'Albastru', '190', '24', 10, '2022-12-12 22:01:02'),
(110, '1', 'Telefon SAMSUNG Galaxy S22 Ultra 5G, 128GB, 8GB, RAM, Dual SIM, Phantom Black', 4749, 'GALAXY S22 ULTRA','Dual SIM','6.8','3088 x 1440','128', '8', 'Octa Core', 'Exynos 2200 (4nm)', '2.8GHz, 2.5GHz, 1.8GHz', 'Cvadrupla', '12MP (Ultra-Wide Angle) f2.2, FF, FOV 120°, 1/2.55”, 1.4µm + 108MP (Wide) f1.8, PD AF, OIS, FOV 85°, 1/1.33”, 0.8µm, Adaptive Pixel + 10MP (Tele) f2.4, Dual Pixel AF, Zoom 3x, OIS, FOV 36°, 1/3.52”, 1.12µm + 10MP (Tele) f4.9, Zoom 10x, Dual Pixel AF, OIS,', '40MP (Wide) f2.2, PD AF, FOV 80°, 1/2.8”, 0.7µm', 'Da', 'Da', '5000', 'Cablu incarcare. Nu contine adaptor priza!', 'Negru', '228', '24', 10, '2022-12-12 22:03:11'),
(111, '1', 'Telefon SAMSUNG Galaxy A13 5G, 64GB, 4GB RAM, Dual SIM, Blue', 750, 'GALAXY A13 5G','Dual SIM','6.5','1600 x 720','64', '4', 'Octa Core', ' ', '2.2 | 2', 'Tripla', '50MP f1.8 + 2MP f2.4 + 2MP f2.4', '5MP f2.0', 'Da', 'Nu', '5000', 'Cablu incarcare. Nu contine adaptor priza!', 'Albastru deschis', '195', '24', 10, '2022-12-12 22:04:58'),
(112, '1', 'Telefon SAMSUNG Galaxy A23 5G, 64GB, 4GB RAM, Dual SIM, Light Blue', 1099, 'GALAXY A23 5G','Dual SIM','6.6','2408 x 1080','64', '4', 'Octa Core', 'Snapdragon 695', '2.2, 1.8', 'Cvadrupla', '50MP f1.8 OIS + 5MP (Ultra Wide) f2.2, FOV 123 + 2MP (Macro) f2.4 + 2MP (Depth) f2.4', '8MP f2.2', 'Nu', 'Nu', '5000', 'Cablu incarcare. Nu contine adaptor priza!', 'Albastru deschis', '197', '24', 10, '2022-12-12 22:06:02'),
(113, '1', 'Telefon SAMSUNG Galaxy A13, 128GB, 4GB RAM, Dual SIM, Black', 929, 'GALAXY A13 2022','Dual SIM','6.6','2408 x 1080','128', '4', 'Octa Core', 'MediaTek | MT6769V/CTZA 64bit', '2GHz, 1.8GHz', 'Cvadrupla', '50MP f1.8 + 5MP (Ultra-Wide Angle) f2.2, FOV 123 + 2MP (Macro) f2.4 + 2MP (Depth) f2.4', '50MP f1.8 + 5MP (Ultra-Wide Angle) f2.2, FOV 123 + 2MP (Macro) f2.4 + 2MP (Depth) f2.4', 'Da', 'Nu', '5000', 'Cablu incarcare. Nu contine adaptor priza!', 'Albastru', '195', '24', 10, '2022-12-12 22:09:02'),
(114, '1', 'Telefon SAMSUNG Galaxy A33 5G, 128GB, 6GB RAM, Dual SIM, Awesome Blue', 1399, 'GALAXY A33','Dual SIM','6.4','1080 x 2400','128', '6', 'Octa Core', ' ', '2.4, 2.0', 'Cvadrupla', '48MP f1.8 + 8MP f2.2 + 5MP f2.4 + 2MP f2.4 AF OIS', '13MP f2.2', 'Da', 'Nu', '5000', 'Cablu incarcare. Nu contine adaptor priza!', 'Albastru deschis', '186', '24', 10, '2022-12-12 22:12:32'),
(115, '1', 'Telefon SAMSUNG Galaxy S21 FE 5G, 256GB, 8GB RAM, Dual SIM, Graphite', 2899, 'GALAXY S21 FAN EDITION','Dual SIM','6.4','2340 x 1080','256', '8', 'Octa Core', 'Qualcomm SM8350 Snapdragon 888 5G (5 nm)', '2.8, 2.4, 1.8', 'Tripla', '12MP (Wide) f/1.8, 26mm, 1/1.76", 1.8µm, Dual Pixel PDAF, OIS + 12MP (Ultra-Wide) f/2.2, 13mm, 123˚, 1/3.0", 1.12µm + 8MP (Telephoto) f/2.4, 76mm, 1/4.5", 1.0µm, PDAF, OIS, 3x optical zoom', '32MP (Wide) f/2.2, 26mm, 1/2.74", 0.8µm', 'Da', 'Da', '4500', ' ', 'Gri', '177', '24', 10, '2022-12-12 22:13:21'),
(116, '1', 'Telefon SAMSUNG Galaxy A13, 128GB, 4GB RAM, Dual SIM, Blue', 929, 'GALAXY A13 2022','Dual SIM','6.6','2408 x 1080','128', '4', 'Octa Core', 'MediaTek | MT6769V/CTZA 64bit', '2GHz, 1.8GHz', 'Cvadrupla', '50MP f1.8 + 5MP (Ultra-Wide Angle) f2.2, FOV 123 + 2MP (Macro) f2.4 + 2MP (Depth) f2.4', '8MP f2.2', 'Da', 'Nu', '5000', 'Cablu incarcare. Nu contine adaptor priza!', 'Albastru', '195', '24', 10, '2022-12-12 22:15:22'),
(117, '1', 'Telefon SAMSUNG Galaxy A13 5G, 128GB, 4GB RAM, Dual SIM, Black', 909, 'GALAXY A13 5G','Dual SIM','6.5','1600 x 720','128', '4', 'Octa Core', ' ', '2.2 | 2', 'Tripla', '50MP f1.8 + 2MP f2.4 + 2MP f2.4', '5MP f2.0', 'Da', 'Nu', '5000', 'Cablu incarcare. Nu contine adaptor priza!', 'Negru', '195', '24', 10, '2022-12-12 22:17:31'),
(118, '1', 'Telefon SAMSUNG Galaxy S22 Ultra 5G, 128GB, 8GB, RAM, Dual SIM, Burgundy', 4749, 'GALAXY S22 ULTRA','Dual SIM','6.8','3088 x 1440','128', '8', 'Octa Core', 'Exynos 2200 (4nm)', '2.8GHz, 2.5GHz, 1.8GHz', 'Cvadrupla', '12MP (Ultra-Wide Angle) f2.2, FF, FOV 120°, 1/2.55”, 1.4µm + 108MP (Wide) f1.8, PD AF, OIS, FOV 85°, 1/1.33”, 0.8µm, Adaptive Pixel + 10MP (Tele) f2.4, Dual Pixel AF, Zoom 3x, OIS, FOV 36°, 1/3.52”, 1.12µm + 10MP (Tele) f4.9, Zoom 10x, Dual Pixel AF, OIS,', '40MP (Wide) f2.2, PD AF, FOV 80°, 1/2.8”, 0.7µm', 'Da', 'Da', '5000', 'Cablu incarcare. Nu contine adaptor priza!', 'Visiniu', '228', '24', 10, '2022-12-12 22:19:45'),
(119, '1', 'Telefon SAMSUNG Galaxy A33 5G, 128GB, 6GB RAM, Dual SIM, Awesome Peach', 1399, 'GALAXY A33','Dual SIM','6.4','1080 x 2400','128', '6', 'Octa Core', ' ', '2.4, 2.0', 'Cvadrupla', '48MP f1.8 + 8MP f2.2 + 5MP f2.4 + 2MP f2.4 AF OIS', '13MP f2.2', 'Da', 'Nu', '5000', 'Cablu incarcare. Nu contine adaptor priza!', 'Portocaliu', '186', '24', 10, '2022-12-12 22:21:01'),
(120, '1', 'Telefon SAMSUNG Galaxy A04s, 32GB, 3GB RAM, Dual SIM, White', 599, 'GALAXY A04S','Dual SIM','6.5','720 x 1600','32', '3', 'Octa Core', ' ', '2.0', 'Tripla', '50MP f1.8 + 2MP f2.4 + 2MP f2.4', '5MP F2.2', 'Nu', 'Nu', '5000', 'Cablu incarcare. Nu contine adaptor priza!', 'Alb', '195', '24', 10, '2022-12-12 22:23:30'),
(121, '1', 'Telefon SAMSUNG Galaxy S22 Ultra 5G, 256GB, 12GB, RAM, Dual SIM, Burgundy', 5299, 'GALAXY S22 ULTRA','Dual SIM','6.8','3088 x 1440','256', '12', 'Octa Core', 'Exynos 2200 (4nm)', '2.8GHz, 2.5GHz, 1.8GHz', 'Cvadrupla', '12MP (Ultra-Wide Angle) f2.2, FF, FOV 120°, 1/2.55”, 1.4µm + 108MP (Wide) f1.8, PD AF, OIS, FOV 85°, 1/1.33”, 0.8µm, Adaptive Pixel + 10MP (Tele) f2.4, Dual Pixel AF, Zoom 3x, OIS, FOV 36°, 1/3.52”, 1.12µm + 10MP (Tele) f4.9, Zoom 10x, Dual Pixel AF, OIS,', '40MP (Wide) f2.2, PD AF, FOV 80°, 1/2.8”, 0.7µm', 'Da', 'Da', '5000', 'Cablu incarcare. Nu contine adaptor priza!', 'Visiniu', '228', '24', 10, '2022-12-12 22:26:21'),
(122, '1', 'Telefon SAMSUNG Galaxy S22 5G, 256GB, 8GB, RAM, Dual SIM, Green', 3399, 'GALAXY S22','Dual SIM','6.1','2340 x 1080','256', '8', 'Octa Core', 'Exynos 2200 (4nm)', '2.8GHz, 2.5GHz, 1.8GHz', 'Tripla', '12MP (Ultra-Wide Angle) f2.2, FF, FOV 120°, 1/2.55”, 1.4µm + 50MP (Wide) f1.8, Dual Pixel AF, OIS, FOV 85°, 1/1.56”, 1.0µm, Adaptive Pixel + 10MP (Tele) f2.4, Zoom 3x, PD AF, OIS, FOV 36°, 1/3.94”, 1.0µm', '10MP (Wide) f2.2, Dual Pixel AF, FOV 80°, 1/3.24”, 1.22µm', 'Da', 'Da', '5000', 'Cablu incarcare. Nu contine adaptor priza!', 'Verde', '167', '24', 10, '2022-12-12 22:28:04'),
(123, '1', 'Telefon SAMSUNG Galaxy S22 Ultra 5G, 512GB, 12GB, RAM, Dual SIM, Phantom Black', 6194, 'GALAXY S22 ULTRA','Dual SIM','6.8','3088 x 1440','512', '12', 'Octa Core', 'Exynos 2200 (4nm)', '2.8GHz, 2.5GHz, 1.8GHz', 'Cvadrupla', '12MP (Ultra-Wide Angle) f2.2, FF, FOV 120°, 1/2.55”, 1.4µm + 108MP (Wide) f1.8, PD AF, OIS, FOV 85°, 1/1.33”, 0.8µm, Adaptive Pixel + 10MP (Tele) f2.4, Dual Pixel AF, Zoom 3x, OIS, FOV 36°, 1/3.52”, 1.12µm + 10MP (Tele) f4.9, Zoom 10x, Dual Pixel AF, OIS,', '40MP (Wide) f2.2, PD AF, FOV 80°, 1/2.8”, 0.7µm', 'Da', 'Da', '5000', 'Cablu incarcare. Nu contine adaptor priza!', 'Negru', '228', '24', 10, '2022-12-12 22:30:56'),
(124, '1', 'Telefon SAMSUNG Galaxy A23 5G, 128GB, 4GB RAM, Dual SIM, Light Blue', 1199, 'GALAXY A23 5G','Dual SIM','6.6','2408 x 1080','128', '4', 'Octa Core', 'Snapdragon 695', '2.2, 1.8', 'Cvadrupla', '50MP f1.8 OIS + 5MP (Ultra Wide) f2.2, FOV 123 + 2MP (Macro) f2.4 + 2MP (Depth) f2.4', '8MP f2.2', 'Nu', 'Nu', '5000', 'Cablu incarcare. Nu contine adaptor priza!', 'Albastru deschis', '197', '24', 10, '2022-12-12 22:33:01'),
(125, '1', 'Telefon SAMSUNG Galaxy S22 Ultra 5G, 128GB, 8GB, RAM, Dual SIM, Phantom White', 4749, 'GALAXY S22 ULTRA','Dual SIM','6.8','3088 x 1440','128', '8', 'Octa Core', 'Exynos 2200 (4nm)', '2.8GHz, 2.5GHz, 1.8GHz', 'Cvadrupla', '12MP (Ultra-Wide Angle) f2.2, FF, FOV 120°, 1/2.55”, 1.4µm + 108MP (Wide) f1.8, PD AF, OIS, FOV 85°, 1/1.33”, 0.8µm, Adaptive Pixel + 10MP (Tele) f2.4, Dual Pixel AF, Zoom 3x, OIS, FOV 36°, 1/3.52”, 1.12µm + 10MP (Tele) f4.9, Zoom 10x, Dual Pixel AF, OIS,', '40MP (Wide) f2.2, PD AF, FOV 80°, 1/2.8”, 0.7µm', 'Da', 'Da', '5000', 'Cablu incarcare. Nu contine adaptor priza!', 'Alb', '228', '24', 10, '2022-12-12 22:35:31'),
(126, '1', 'Telefon SAMSUNG Z Flip4 5G, 256GB, 8GB RAM, Dual SIM, Bora Purple', 4304, 'GALAXY Z FLIP4','Dual SIM','6.7','2640 x 1080','256', '8', 'Octa Core', 'Snapdragon 8+ Gen 1 (4nm)', '3.18 (Maximum Clock Speed) + 2.7 + 2.0', 'Duala', '12 MP (Ultra-Wide) FF F2.2 123° 1.12 µm + 12MP (Wide) Dual Pixel F1.8 1.8µm OIS, FOV 83˚', '10MP 1.22µm FF, F2.4, FOV 80˚', 'Da', 'Da', '3700', ' ', 'Violet', '187', '24', 10, '2022-12-12 22:37:58'),
(127, '1', 'Telefon SAMSUNG Galaxy A23 5G, 128GB, 4GB RAM, Dual SIM, Light Blue', 1199, 'GALAXY A23 5G','Dual SIM','6.1','2340 x 1080','256', '8', 'Octa Core', 'Exynos 2200 (4nm)', '2.8GHz, 2.5GHz, 1.8GHz', 'Tripla', '12MP (Ultra-Wide Angle) f2.2, FF, FOV 120°, 1/2.55”, 1.4µm + 50MP (Wide) f1.8, Dual Pixel AF, OIS, FOV 85°, 1/1.56”, 1.0µm, Adaptive Pixel + 10MP (Tele) f2.4, Zoom 3x, PD AF, OIS, FOV 36°, 1/3.94”, 1.0µm', '10MP (Wide) f2.2, Dual Pixel AF, FOV 80°, 1/3.24”, 1.22µm', 'Da', 'Da', '3700', ' ', 'Alb', '167', '24', 10, '2022-12-12 22:40:09'),
(128, '1', 'Telefon SAMSUNG Galaxy Z Fold4 5G, 256GB, 12GB RAM, Dual SIM, Graygreen', 6999, 'GALAXY Z FOLD4','Dual SIM','7.6','2176 x 1812','256', '12', 'Octa Core', 'Snapdragon 8+ Gen 1 4㎚ 64-bit', '3.18 (Maximum Clock Speed) + 2.7 + 2.0', 'Tripla', '12MP (Ultra-Wide) 1.12 µm, F2.2, FOV 123˚ + 50MP (Wide) 1.0μm (12MP 2.0μm), OIS, Dual Pixel AF, F1.8, FOV 85˚ + 10MP (Telephoto) 1.0µm, OIS, PDAF, F2.4, FOV 36˚', 'Front 4MP (Under Display Camera) 2.0µm FF, F1.8, FOV 80˚ + Cover 10MP 1.22µm FF, F2.2, FOV 85˚', 'Da', 'Da', '4400', ' ', 'Gri', '263', '24', 10, '2022-12-12 22:42:11'),
(129, '1', 'Telefon SAMSUNG Galaxy Z Fold4 5G, 512GB, 12GB RAM, Dual SIM, Phantom Black', 7176, 'GALAXY Z FOLD4','Dual SIM','7.6','2176 x 1812','512', '12', 'Octa Core', 'Snapdragon 8+ Gen 1 4㎚ 64-bit', '3.18 (Maximum Clock Speed) + 2.7 + 2.0', 'Tripla', '12MP (Ultra-Wide) 1.12 µm, F2.2 + 50MP (Wide) 2.0µm (@12MP) OIS Dual Pixel AF, F1.8 + 10MP (Tele) 1.0µm OIS PDAF 3x zoom optic, F2.4', 'Front 4MP (Under Display Camera) 2.0µm FF, F1.8, FOV 80˚ + Cover 10MP 1.22µm FF, F2.2, FOV 85˚', 'Da', 'Da', '4400', ' ', 'Negru', '263', '24', 10, '2022-12-12 22:44:45'),
(130, '1', 'Telefon APPLE iPhone 11, 64GB, Black', 2499, 'IPHONE 11','Single SIM','6.1','1792 x 828','64', '4', 'Hexa Core', 'A13 Bionic chip, Neural Engine Generatia a treia', ' ', 'Duala', '12 MP Ultra Wide, f2.4, FOV 120° + 12MP Wide f1.8', '12MP TrueDepth f2.2, Mod Portret cu Bokeh si Depth Control, Iluminare portret cu 6 efecte, Animoji si Memoji, Inregistrare 4K', 'Nu', 'Da', '3110', 'Doar cablu incarcare inclus. Pachetul nu contine Adaptor priza si Casti', 'Negru', '194', '24', 11, '2022-12-13 19:30:15'),
(131, '1', 'Telefon APPLE iPhone 13 5G, 128GB, Midnight', 4199, 'IPHONE 13','Dual SIM','6.1','2532 x 1170','128', '4', 'Hexa Core', 'A15 Bionic chip + 16-core Neural Engine', ' ', 'Duala', '12MP (Wide ) f1.6 + 12MP (Ultra Wide ) f2.4, FOV 120', '12MP (TrueDepth) f2.2, Portrait mode, Portrait Lighting, Animoji, Memoji, Night mode, Deep Fusion, Smart HDR 4, HDR video 4K, Slo-mo video 1080p, Time-lapse video with stabilisation, Night mode Time-lapse, Retina Flash, Auto image stabilisation', 'Da', 'Da', '3240', 'Doar cablu incarcare inclus. Pachetul nu contine Adaptor priza si Casti', 'Negru', '173', '24', 11, '2022-12-13 19:32:23'),
(132, '1', 'Telefon APPLE iPhone 11, 128GB, White', 2799, 'IPHONE 11','Single SIM','6.1','1792 x 828','128', '4', 'Hexa Core', 'A13 Bionic chip, Neural Engine Generatia a treia', ' ', 'Duala', '12 MP Ultra Wide, f2.4, FOV 120° + 12MP Wide f1.8', '12MP TrueDepth f2.2, Mod Portret cu Bokeh si Depth Control, Iluminare portret cu 6 efecte, Animoji si Memoji, Inregistrare 4K', 'Nu', 'Da', '3110', 'Doar cablu incarcare inclus. Pachetul nu contine Adaptor priza si Casti', 'Alb', '194', '24', 11, '2022-12-13 19:33:59'),
(133, '1', 'Telefon APPLE iPhone 14 Plus 5G, 128GB, Midnight', 5499, 'IPHONE 14 PLUS','Dual SIM','6.7','2778 x 1284','128', '4', 'Hexa Core', 'A15 Bionic chip, 6‑core CPU with 2 performance and 4 efficiency cores, 5‑core GPU, 16‑core Neural Engine', ' ', 'Duala', '12MP 26 mm, ƒ/1.5, sensor‑shift OIS, 7 element Lens, 100% Focus Pixels + 12MP (Ultra Wide) 13 mm, ƒ/2.4, FOV 120°, 5 element Lens', '12MP ƒ/1.9, AF, 6 elements Lens, Retina Flash, Photonic Engine, Deep Fusion, Smart HDR 4, Night mode, Auto image stabilization, Burst mode, Inregistrare video 4K/1080p', 'Da', 'Da', ' ', 'Doar cablu incarcare inclus (USB-C - Lightning). Pachetul nu contine Adaptor priza si Casti', 'Gri inchis', '203', '24', 11, '2022-12-13 19:36:05'),
(134, '1', 'Telefon APPLE iPhone 14 5G, 128GB, Purple', 4549, 'IPHONE 14','Dual SIM','6.1','2532 x 1170','128', '6', 'Hexa Core', 'A15 Bionic chip, 6‑core CPU with 2 performance and 4 efficiency cores, 5‑core GPU, 16‑core Neural Engine', ' ', 'Duala', '12MP 26 mm, ƒ/1.5, sensor‑shift OIS, 7 element Lens, 100% Focus Pixels + 12MP (Ultra Wide) 13 mm, ƒ/2.4, FOV 120°, 5 element Lens', '12MP ƒ/1.9, AF, 6 elements Lens, Retina Flash, Photonic Engine, Deep Fusion, Smart HDR 4, Night mode, Auto image stabilization, Burst mode, Inregistrare video 4K/1080p', 'Da', 'Da', ' ', 'Doar cablu incarcare inclus (USB-C - Lightning). Pachetul nu contine Adaptor priza si Casti', 'Violet', '172', '24', 11, '2022-12-13 19:39:41'),
(135, '1', 'Telefon APPLE iPhone 14 Plus 5G, 128GB, Blue', 5298, 'IPHONE 14 PLUS','Dual SIM','6.7','2778 x 1284','128', '4', 'Hexa Core', 'A15 Bionic chip, 6‑core CPU with 2 performance and 4 efficiency cores, 5‑core GPU, 16‑core Neural Engine', ' ', 'Duala', '12MP 26 mm, ƒ/1.5, sensor‑shift OIS, 7 element Lens, 100% Focus Pixels + 12MP (Ultra Wide) 13 mm, ƒ/2.4, FOV 120°, 5 element Lens', '12MP ƒ/1.9, AF, 6 elements Lens, Retina Flash, Photonic Engine, Deep Fusion, Smart HDR 4, Night mode, Auto image stabilization, Burst mode, Inregistrare video 4K/1080p', 'Da', 'Da', ' ', 'Doar cablu incarcare inclus (USB-C - Lightning). Pachetul nu contine Adaptor priza si Casti', 'Albastru', '203', '24', 11, '2022-12-13 19:42:00'),
(136, '1', 'Telefon APPLE iPhone 14 Pro Max 5G, 128GB, Deep Purple', 7069, 'IPHONE 14 PRO MAX','Dual SIM','6.7','2796 x 1290','128', '6', 'Hexa Core', 'A16 Bionic chip, 6‑core CPU with 2 performance and 4 efficiency cores, 5‑core GPU, 16‑core Neural Engine', ' ', 'Cvadrupla', '48MP, 24 mm, ƒ/1.78, sensor-shift OIS 2nd Gen, 7 element lens + 12MP (Ultra Wide) 13 mm, ƒ/2.2, FOV 120°, 6 element lens + 12MP (Telephoto) 48 mm, ƒ/1.78, sensor-shift OIS 2nd Gen, 7 element lens +12MP (Telephoto) 77 mm, ƒ/2.8, OIS, 6 element lens', '12MP ƒ/1.9, AF, 6 elements Lens, Retina Flash, Photonic Engine, Deep Fusion, Smart HDR 4, Night mode, Auto image stabilization, Burst mode, Inregistrare video 4K/1080p', 'Da', 'Da', ' ', 'Doar cablu incarcare inclus (USB-C - Lightning). Pachetul nu contine Adaptor priza si Casti', 'Violet', '206', '24', 11, '2022-12-13 19:43:55'),
(137, '1', 'Telefon APPLE iPhone 12 5G, 64GB, Black', 3515, 'IPHONE 12','Single SIM','6.1','2532 x 1170','64', '4', 'Hexa Core', 'A14 Bionic (5nm)', ' ', 'Duala', '12MP (Ultra-Wide) f/2.4, FOV 120°, 5 elements Lens, + 12MP (Wide) f/1.6, OIS, 7 elements Lens, 100% Focus Pixels', '12MP (Depth) f/2.2, Portrait mode | Portrait Lighting | Animoji and Memoji | Night mode | Deep Fusion | Smart HDR 3 | HDR video | 4K video | Slo mo video 1080p, Time lapse video cu stabilizare | Cinematic video stabilization | QuickTake video | Lens corre', 'Da', 'Da', ' ', 'Doar cablu incarcare inclus. Pachetul nu contine Adaptor priza si Casti', 'Negru', '164', '24', 11, '2022-12-13 19:46:03'),
(138, '1', 'Telefon APPLE iPhone 14 Pro Max 5G, 256GB, Deep Purple', 7699, 'IPHONE 14 PRO MAX','Dual SIM','6.7','2796 x 1290','256', '6', 'Hexa Core', 'A16 Bionic chip, 6‑core CPU with 2 performance and 4 efficiency cores, 5‑core GPU, 16‑core Neural Engine', ' ', 'Cvadrupla', '48MP, 24 mm, ƒ/1.78, sensor-shift OIS 2nd Gen, 7 element lens + 12MP (Ultra Wide) 13 mm, ƒ/2.2, FOV 120°, 6 element lens + 12MP (Telephoto) 48 mm, ƒ/1.78, sensor-shift OIS 2nd Gen, 7 element lens +12MP (Telephoto) 77 mm, ƒ/2.8, OIS, 6 element lens', '12MP ƒ/1.9, AF, 6 elements Lens, Retina Flash, Photonic Engine, Deep Fusion, Smart HDR 4, Night mode, Auto image stabilization, Burst mode, Inregistrare video 4K/1080p', 'Da', 'Da', ' ', 'Doar cablu incarcare inclus (USB-C - Lightning). Pachetul nu contine Adaptor priza si Casti', 'Violet', '206', '24', 11, '2022-12-13 19:48:12'),
(139, '1', 'Telefon APPLE iPhone 14 Pro Max 5G, 256GB, Silver', 7699, 'IPHONE 14 PRO MAX','Dual SIM','6.7','2796 x 1290','256', '6', 'Hexa Core', 'A16 Bionic chip, 6‑core CPU with 2 performance and 4 efficiency cores, 5‑core GPU, 16‑core Neural Engine', ' ', 'Cvadrupla', '48MP, 24 mm, ƒ/1.78, sensor-shift OIS 2nd Gen, 7 element lens + 12MP (Ultra Wide) 13 mm, ƒ/2.2, FOV 120°, 6 element lens + 12MP (Telephoto) 48 mm, ƒ/1.78, sensor-shift OIS 2nd Gen, 7 element lens +12MP (Telephoto) 77 mm, ƒ/2.8, OIS, 6 element lens', '12MP ƒ/1.9, AF, 6 elements Lens, Retina Flash, Photonic Engine, Deep Fusion, Smart HDR 4, Night mode, Auto image stabilization, Burst mode, Inregistrare video 4K/1080p', 'Da', 'Da', ' ', 'Doar cablu incarcare inclus (USB-C - Lightning). Pachetul nu contine Adaptor priza si Casti', 'Argintiu', '206', '24', 11, '2022-12-13 19:50:23'),
(140, '1', 'Telefon APPLE iPhone 13 5G, 128GB, (PRODUCT)RED', 4179, 'IPHONE 13','Dual SIM','6.1','2532 x 1170','128', '4', 'Hexa Core', 'A15 Bionic chip + 16-core Neural Engine', ' ', 'Duala', '12MP (Wide ) f1.6 + 12MP (Ultra Wide ) f2.4, FOV 120', '12MP (TrueDepth) f2.2, Portrait mode, Portrait Lighting, Animoji, Memoji, Night mode, Deep Fusion, Smart HDR 4, HDR video 4K, Slo-mo video 1080p, Time-lapse video with stabilisation, Night mode Time-lapse, Retina Flash, Auto image stabilisation', 'Da', 'Da', '3240', 'Doar cablu incarcare inclus. Pachetul nu contine Adaptor priza si Casti', 'Rosu', '173', '24', 11, '2022-12-13 19:52:40'),
(141, '1', 'Telefon APPLE iPhone 12 5G, 128GB, Purple', 3989, 'IPHONE 12','Single SIM','6.1','2532 x 1170','128', '4', 'Hexa Core', 'A14 Bionic (5nm)', ' ', 'Duala', '12MP (Ultra-Wide) f/2.4, FOV 120°, 5 elements Lens, + 12MP (Wide) f/1.6, OIS, 7 elements Lens, 100% Focus Pixels', '12MP (Depth) f/2.2, Portrait mode | Portrait Lighting | Animoji and Memoji | Night mode | Deep Fusion | Smart HDR 3 | HDR video | 4K video | Slo mo video 1080p, Time lapse video cu stabilizare | Cinematic video stabilization | QuickTake video | Lens corre', 'Da', 'Da', ' ', 'Doar cablu incarcare inclus. Pachetul nu contine Adaptor priza si Casti', 'Violet', '164', '24', 11, '2022-12-13 19:55:43'),
(142, '1', 'Telefon APPLE iPhone 14 Pro 5G, 1TB, Gold', 9468, 'IPHONE 14 PRO','Dual SIM','6.1','2556 x 1179','1024', '6', 'Hexa Core', 'A16 Bionic chip, 6‑core CPU with 2 performance and 4 efficiency cores, 5‑core GPU, 16‑core Neural Engine', ' ', 'Cvadrupla', '48MP, 24 mm, ƒ/1.78, sensor-shift OIS 2nd Gen, 7 element lens + 12MP (Ultra Wide) 13 mm, ƒ/2.2, FOV 120°, 6 element lens + 12MP (Telephoto) 48 mm, ƒ/1.78, sensor-shift OIS 2nd Gen, 7 element lens +12MP (Telephoto) 77 mm, ƒ/2.8, OIS, 6 element lens', '12MP ƒ/1.9, AF, 6 elements Lens, Retina Flash, Photonic Engine, Deep Fusion, Smart HDR 4, Night mode, Auto image stabilization, Burst mode, Inregistrare video 4K/1080p', 'Da', 'Da', ' ', 'Doar cablu incarcare inclus (USB-C - Lightning). Pachetul nu contine Adaptor priza si Casti', 'Auriu', '240', '24', 11, '2022-12-13 19:57:55'),
(143, '1', 'Telefon APPLE iPhone 14 Pro Max 5G, 512GB, Gold', 7699, 'IPHONE 14 PRO MAX','Dual SIM','6.7','2796 x 1290','512', '6', 'Hexa Core', 'A16 Bionic chip, 6‑core CPU with 2 performance and 4 efficiency cores, 5‑core GPU, 16‑core Neural Engine', ' ', 'Cvadrupla', '48MP, 24 mm, ƒ/1.78, sensor-shift OIS 2nd Gen, 7 element lens + 12MP (Ultra Wide) 13 mm, ƒ/2.2, FOV 120°, 6 element lens + 12MP (Telephoto) 48 mm, ƒ/1.78, sensor-shift OIS 2nd Gen, 7 element lens +12MP (Telephoto) 77 mm, ƒ/2.8, OIS, 6 element lens', '12MP ƒ/1.9, AF, 6 elements Lens, Retina Flash, Photonic Engine, Deep Fusion, Smart HDR 4, Night mode, Auto image stabilization, Burst mode, Inregistrare video 4K/1080p', 'Da', 'Da', ' ', 'Doar cablu incarcare inclus (USB-C - Lightning). Pachetul nu contine Adaptor priza si Casti', 'Auriu', '206', '24', 11, '2022-12-13 19:59:21'),
(144, '1', 'Telefon APPLE iPhone 11, 128GB, Purple', 2938, 'IPHONE 11','Single SIM','6.1','1792 x 828','128', '4', 'Hexa Core', 'A13 Bionic chip, Neural Engine Generatia a treia', ' ', 'Duala', '12 MP Ultra Wide, f2.4, FOV 120° + 12MP Wide f1.8', '12MP TrueDepth f2.2, Mod Portret cu Bokeh si Depth Control, Iluminare portret cu 6 efecte, Animoji si Memoji, Inregistrare 4K', 'Nu', 'Da', '3110', 'Doar cablu incarcare inclus. Pachetul nu contine Adaptor priza si Casti', 'Violet', '194', '24', 11, '2022-12-13 20:01:10'),
(145, '1', 'Telefon APPLE iPhone 11, 64GB, White', 2399, 'IPHONE 11','Single SIM','6.1','1792 x 828','64', '4', 'Hexa Core', 'A13 Bionic chip, Neural Engine Generatia a treia', ' ', 'Duala', '12 MP Ultra Wide, f2.4, FOV 120° + 12MP Wide f1.8', '12MP TrueDepth f2.2, Mod Portret cu Bokeh si Depth Control, Iluminare portret cu 6 efecte, Animoji si Memoji, Inregistrare 4K', 'Nu', 'Da', '3110', 'Doar cablu incarcare inclus. Pachetul nu contine Adaptor priza si Casti', 'Alb', '194', '24', 11, '2022-12-13 20:03:01'),
(146, '1', 'Telefon APPLE iPhone SE 5G, 64GB, Starlight', 1789, 'IPHONE SE 3','Single SIM','4.7','1334 x 750','64', '4', 'Hexa Core', 'A15 Bionic chip, 16-core Neural Engine', ' ', 'Single', '12MP (Wide) f1.8', '7MP f2.2, Portrait mode cu Bokeh si Depth Control. Portrait Lighting cu 6 efecte (Natural, Studio, Contour, Stage, Stage Mono, High-Key Mono), Deep Fusion, Smart HDR 4, Video 1080p HD video recording at 25 fps or 30 fps, Time‑lapse video cu stabilizare', 'Da', 'Da', ' ', ' ', 'Crem', '144', '24', 11, '2022-12-13 20:05:34'),
(147, '1', 'Telefon APPLE iPhone SE 5G, 128GB, Midnight', 2068, 'IPHONE SE 3','Single SIM','4.7','1334 x 750','128', '4', 'Hexa Core', 'A15 Bionic chip, 16-core Neural Engine', ' ', 'Single', '12MP (Wide) f1.8', '7MP f2.2, Portrait mode cu Bokeh si Depth Control. Portrait Lighting cu 6 efecte (Natural, Studio, Contour, Stage, Stage Mono, High-Key Mono), Deep Fusion, Smart HDR 4, Video 1080p HD video recording at 25 fps or 30 fps, Time‑lapse video cu stabilizare', 'Da', 'Da', ' ', ' ', 'Negru', '144', '24', 11, '2022-12-13 20:07:58'),
(148, '1', 'Telefon HUAWEI nova Y90, 128GB, 6GB RAM, Dual SIM, Midnight Black', 949, 'NOVA Y90','Dual SIM','6.7','2388 x 1080','128', '6', 'Octa Core', 'Qualcomm Snapdragon 680', '4 x Cortex-A73 Based 2.4 GHz + 4 x Cortex-A53 Based 1.9 GHz', 'Tripla', '50MP (High-Res) f/1.8 + 2MP (Macro) f/2.4 + 2MP (Depth) f/2.4', '8MP f/2.0', 'Da', 'Nu', '5000', 'Incarcator, Cablu USB Type C', 'Negru', '195', '24', 12, '2022-12-13 20:30:12'),
(149, '1', 'Telefon HUAWEI nova Y70, 128GB, 4GB RAM, Dual SIM, Crystal Blue', 788, 'NOVA Y70','Dual SIM','6.75','1600 x 720','128', '4', 'Octa Core', ' ', ' ', 'Tripla', '48MP (High-Res) f/1.8 + 5MP (Ultra-Wide Angle) f/2.2, FOV 120° + 2MP (Depth) f/2.4', '8MP f/2.0', 'Da', 'Nu', '6000', 'Incarcator, Cablu USB Type C', 'Albastru', '199', '24', 12, '2022-12-13 20:33:02'),
(150, '1', 'Telefon HUAWEI nova 10 SE, 128GB, 8GB RAM, Dual SIM, Starry Black', 1649, 'NOVA 10 SE','Dual SIM','6.67','2400 x 1080','128', '8', 'Octa Core', 'Qualcomm Snapdragon 680G 4G', '4x Cortex-A73@2,4 GHz + 4x Cortex - A53@1,9 GHz', 'Tripla', '108MP f/1.9 EIS + 8MP (Depth & Ultra-Wide Angle) f/2.2 + 2MP (Macro) f/2.4', '16MP f/2.2, Rezolutie foto 4608 × 3456 pixeli, Rezolutie video 1920 × 1080 pixeli, Noapte, Portret, Time-lapse, Filtru, Smiley Face Snap, Selfie Mirror, Control audio, Timer, Gesture Photo', 'Da', 'Nu', '4500', 'Incarcator HUAWEI SuperCharge, Cablu USB-C', 'Negru', '182', '24', 3, '2022-12-13 20:36:40'),
(151, '1', 'Telefon HUAWEI nova 10 Pro, 256GB, 8GB RAM, Dual SIM, Starry Silver', 2959, 'HUAWEI NOVA 10 PRO','Dual SIM','6.78','2652 x 1200','256', '8', 'Octa Core', 'Qualcomm Snapdragon 778G 4G', ' ', 'Tripla', '50MP (Ultra Vision) f/1.8 + 8MP (Ultra-Wide & Macro) f/2.2 + 2MP (Portrait & Depth) f/2.4', '60MP (Ultra-Wide) f/2.4, AF + 8MP (Portrait Close-up) f/2.2', 'Da', 'Nu', '4500', 'Incarcator, Cablu USB-C', 'Argintiu', '191', '24', 12, '2022-12-13 20:38:58'),
(152, '1', 'Telefon HUAWEI Mate 50 Pro, 256GB, 8GB RAM, Dual SIM, Silver', 5999, 'MATE 50 PRO','Dual SIM','6.74','2616 x 1212','256', '8', 'Octa Core', 'Snapdragon 8+ Gen 1 4G, Motor Qualcomm AI a 7-a generație', '1 x Cortex-X2@3,2 GHz + 3 x Cortex-A710@2,75 GHz + 4 x Cortex-A510@2,0 GHz', 'Tripla', '50MP (Ultra Aperture Camera) f/1.4~f/4.0, OIS + 13MP (Ultra-Wide Angle) f/2.2 + 64MP (Telephoto) f/3.5, OIS', '13MP (Wide Angle) f/2.4, Rezolutie video 4K (3840 x 2160), Rezolutie foto 4160 × 3120 pixeli', 'Da', 'Nu', '4700', 'Cablu USB-C, Incarcator', 'Argintiu', '209', '24', 12, '2022-12-13 20:41:19'),
(153, '1', 'Telefon HUAWEI P50 Pro, 256GB, 8GB RAM, Dual SIM, Cocoa Gold', 3999, 'P50 PRO','Dual SIM','6.6','2700 x 1228','256', '8', 'Octa Core', 'Snapdragon 888 4G', '1x Cortex-X1@2.84GHz + 3x Cortex-A78@2.42GHz + 4x Cortex-A55@1.8GHz', 'Cvadrupla', '50MP (True-Chroma) Color, f/1.8, OIS + 40MP (True-Chroma) (Mono, f/1.6 + 13MP (Ultra-Wide Angle) f/2.2 + 64MP (Telephoto) f/3.5, OIS, AF', '13MP (Wide Angle), f/2.4, AF, Rezolutie foto 4160 × 3120 pixeli, Rezolutie video 3840 × 2160 pixeli, Slow-Motion Selfie, Intelligent Field Of View, Smart eye-tracking, Portrait, Panorama, AR Lens, Time-Lapse, Moving Picture, Filter, Stickers', 'Da', 'Da', '4360', ' ', 'Auriu', '195', '24', 12, '2022-12-13 20:43:31'),
(154, '1', 'Telefon HUAWEI nova Y61, 64GB, 4GB RAM, Dual SIM, Mint Green', 899, 'NOVA Y61','Dual SIM','6.52','1600 x 720','64', '4', 'Octa Core', ' ', ' ', 'Tripla', '50MP f1.8 + 2MP (Macro) f2.4, 4cm + 2MP (Depth) f2.4', '5MP f2.2, Rezolutie foto 2592x1944 pixels, Rezolutie video: 1920x1080 pixels, Photo Mode, Portrait Mode', 'Da', 'Nu', '5000', 'Incarcator, Cablu', 'Verde deschis', '188', '24', 12, '2022-12-13 20:46:01'),
(155, '1', 'Telefon HUAWEI nova 9 SE, 128GB, 8GB RAM, Dual SIM, Midnight Black', 1098, 'HUAWEI NOVA 9SE','Dual SIM','6.78','2388 x 1080','128', '8', 'Octa Core', 'Qualcomm Snapdragon 680', ' ', 'Cvadrupla', '108MP f/1.9 + 8MP (Ultra-Wide Angle) (f/2.2 + 2MP (Depth) f/2.4 + 2MP (Macro) f/2.4', '16MP f/2.2, Rezolutie foto pana la 4608 x 3456, Rezolutie video pana la 1920 x 1080', 'Da', 'Nu', '4000', ' ', 'Negru', '191', '24', 12, '2022-12-13 20:48:41'),
(156, '1', 'Telefon HUAWEI Mate Xs 2, 512GB, 8GB RAM, Dual SIM, Black', 8549, 'Mate Xs 2','Dual SIM','7.8','2480 x 2200','512', '8', 'Octa Core', 'Snapdragon 888 4G', '1 x Cortex-X1@2.84 GHz + 3 x Cortex-A78@2.42 GHz + 4 x Cortex-A55@1.8 GHz', 'Tripla', '50MP (True-Chroma) (Wide Angle) f/1.8 + 13MP (Ultra-Wide Angle) f/2.2 + 8 MP (Telephoto) f/2.4 OIS', '10.7MP (Wide Angle) f/2.2, Rezolutie imagine 3776 x 2832 pixels, Rezolutie video 3840 x 2160 pixels, Slow-Motion, Intelligent Field of View, Portrait, Panorama, AR Lens, Time-Lapse, Moving Picture, Filter, Stickers, Capture Smiles, Mirror Reflection, Audi', 'Da', 'Nu', '4600', 'Incarcator, Cablu USB Type C', 'Negru', '255', '24', 12, '2022-12-13 20:51:03'),
(157, '1', 'Telefon HUAWEI Mate 50 Pro, 512GB, 8GB RAM, Dual SIM, Orange', 6499, 'MATE 50 PRO','Dual SIM','6.74','2616 x 1212','512', '8', 'Octa Core', 'Snapdragon 8+ Gen 1 4G, Motor Qualcomm AI a 7-a generație', '1 x Cortex-X2@3,2 GHz + 3 x Cortex-A710@2,75 GHz + 4 x Cortex-A510@2,0 GHz', 'Tripla', '50MP (Ultra Aperture Camera) f/1.4~f/4.0, OIS + 13MP (Ultra-Wide Angle) f/2.2 + 64MP (Telephoto) f/3.5, OIS', '13MP (Wide Angle) f/2.4, Rezolutie video 4K (3840 x 2160), Rezolutie foto 4160 × 3120 pixeli', 'Da', 'Nu', '4700', 'Cablu USB-C, Incarcator', 'Portocaliu', '205', '24', 12, '2022-12-13 20:53:23'),
(158, '1', 'Telefon HUAWEI P50 Pocket, 256GB, 8GB RAM, Dual SIM, White', 3869, 'P50 POCKET','Dual SIM','6.9','2790 x 1188','256', '8', 'Octa Core', 'Snapdragon 888 4G', '1x Cortex-X1@2.84GHz + 3x Cortex-A78@2.42GHz + 4x Cortex-A55@1.8GHz', 'Cvadrupla', '40MP (True-Chroma) (Mono, f/1.8 + 13MP (Ultra-Wide Angle) f/2.2 + 32MP (Ultra Spectrum) f/1.8, AF', '10.7MP (Wide Angle), f/2.2, AF, Rezolutie foto 3776 x 2832 pixeli, Rezolutie video 3840 × 2160 pixeli, Slow-Motion, Intelligent Field of View, Portrait, Panorama, Time-Lapse, Moving Picture, Filter, Stickers, Capture Smiles, Mirror Reflection', 'Da', 'Nu', '4000', ' ', 'Alb', '190', '24', 12, '2022-12-13 20:56:01'),
(159, '1', 'Telefon XIAOMI Redmi Note 11 Pro+ 5G, 128GB, 6GB RAM, Dual SIM, Graphite Gray', 2025, 'REDMI NOTE 11 PRO+','Dual SIM','6.67','1080 x 2400','128', '6', 'Octa Core', 'MediaTek Dimensity 920 6nm', 'Pana la 2.5', 'Tripla', '108MP f/1.8 + 8MP (Ultra-Wide Angle) f/2.2, FOV 120° + 2MP (Macro) f2.4', '16MP 2.4, Rezolutie video 1080p', 'Da', 'Nu', '4500', '	Cablu USB Type-C, adaptor 120W', 'Gri', '204', '24', 13, '2022-12-13 21:21:15'),
(160, '1', 'Telefon XIAOMI Redmi Note 11 Pro 5G, 128GB, 6GB RAM, Dual SIM, Graphite Gray', 1500, 'REDMI NOTE 11 PRO 5G','Dual SIM','6.67','2400 x 1080','128', '6', 'Octa Core', 'Snapdragon 695', 'Pana la 2.2', 'Tripla', '108MP(Wide) f/1.9, 0.7μm, 9-in-1 binning into one large 2.1μm pixel, senzor size 1/1.52” + 8MP (Ultra-Wide) f/2.2, FOV 118° + 2MP (Macro) f/2.4', '16MP f/2.4, Rezolutie video 1080p', 'Da', 'Nu', '5000', 'Adaptor 67W, Cablu USB Type C', 'Gri', '202', '24', 13, '2022-12-13 21:24:21'),
(161, '1', 'Telefon XIAOMI Redmi Note 11s, 64GB, 6GB RAM, Dual SIM, Graphite Gray', 1050, 'REDMI NOTE 11S','Dual SIM','6.43','2400 x 1080','64', '4', 'Octa Core', 'MediaTek Helio G96', 'Pana la 2.05', 'Cvadrupla', '108MP (Wide) f/1.9, 0.7μm, 1/1.52” + 8MP (ultra-Wide) f/2.2, FOV 118° + 2MP (Macro) f/2.4 + 2MP (Depth) f/2.4', '16MP f/2.4, Video 1080p 1920x1080 | 30fps, 720p 1280x720 | 30fps', 'Da', 'Nu', '5000', 'Adaptor 33W, cablu USB Type-C', 'Gri inchis', '179', '24', 13, '2022-12-13 21:27:54'),
(162, '1', 'Telefon XIAOMI Redmi 10C, 64GB, 4GB RAM, Dual SIM, Graphite Gray', 691, 'REDMI 10C','Dual SIM','6.71','1650 x 720','64', '4', 'Octa Core', 'Snapdragon 680 6nm', 'Pana la 2.4', 'Duala', '50MP f/1.8, 4-in-1 pixel binning + 2MP (Depth) f/2.4', '5MP f/2.2, Rezolutie video 1080p', 'Da', 'Nu', '5000', 'Adaptor 10W, Cablu USB Type C', 'Gri', '190', '24', 13, '2022-12-13 21:30:23'),
(163, '1', 'Telefon XIAOMI 12X 5G, 128GB, 8GB RAM, Dual SIM, Blue', 3177, 'XIAOMI 12X','Dual SIM','6.28','1080 x 2400','128', '8', 'Octa Core', 'Snapdragon 870 7nm, Kryo 585 CPU pana la 3.2GHz', '1x Prime core (A77-based), 3.2GHz + 3x Gold cores (A77-based), 2.42GHz + 4x Silver cores (A55-based), 1.8GHz', 'Tripla', '50MP (Wide angle) f/1.88, 1/1.56” sensor size, 1.0μm pixel size, 2μm 4-in-1 Super Pixel + 13MP (ultra-wide angle) FOV 123°, f/2.4 + 5MP (telemacro) AF (3cm-7cm)', '32MP f/2.45, Selfie Night mode, AI Beautify, AI portrait mode cu bokeh si depth control, HDR, Dual video (Wide, Selfie), AI portrait video, Time-lapse selfie', 'Da', 'Da', '4500', 'Cablu USB Type-C, adaptor 67W', 'Albastru deschis', '176', '24', 13, '2022-12-13 21:33:26'),
(164, '1', 'Telefon XIAOMI 11 Lite 5G NE, 128GB, 6GB RAM, Dual SIM, Truffle Black', 1594, 'XIAOMI 11 LITE 5G NE','Dual SIM','6.55','2400 x 1080','128', '6', 'Octa Core', 'Qualcomm Snapdragon 778G 6nm, Qualcomm Kryo 670', 'Pana la 2.4GHz', 'Tripla', '64MP f/1.79, 6P lens, 1/1.97", 0.7µm, 4-in-1 Super Pixel + 8MP (Ultra Wide-Angle) FOV 119°, f/2.2, 1.4", 1.12µm, 5P Lens + 5MP (TeleMacro) f/2.4, Contrast AF (3cm-7cm), 1.5", 1.12µm, 4P Lens', '20MP, f/2.24, Night mode, AI Beautify, Time-lapse selfie', 'Da', 'Nu', '4250', 'Adaptor incarcare 33W, Cablu USB Type-C', 'Negru', '158', '24', 13, '2022-12-13 21:35:46'),
(165, '1', 'Telefon XIAOMI 12 Pro 5G, 256GB, 12GB RAM, Dual SIM, Purple', 4598, 'XIAOMI 12 PRO','Dual SIM','6.73','3200 x 1440','256', '12', 'Octa Core', 'Snapdragon 8 Gen 1 4nm, tehnologie Armv9 Cortex-X2, 7th Gen Qualcomm AI Engine', '1x Prime core (X2-based), 3.0GHz + 3x Gold cores (A710-based), 2.5GHz + 4x Silver cores (A510-based), 1.8GHz', 'Tripla', '50MP (wide angle), 1/1.28” sensor size, 1.22μm pixel size, 2.44μm 4-in-1 Super Pixel, f/1.9, OIS + 50MP (ultra-wide angle) FOV 115°, f/2.2 + 50MP (telephoto) f/1.9, 48mm', '32MP f/2.45, Selfie Night mode, Timed burst, AI Beautify, AI portrait mode cu bokeh si depth control, HDR, Panorama selfies, Video HDR, Dual video (Wide, Selfie), AI portrait video, Time-lapse selfie', 'Da', 'Da', '4600', 'Cablu USB Type-C, adaptor 120W', 'Violet', '180', '24', 13, '2022-12-13 21:38:02'),
(166, '1', 'Telefon XIAOMI 11T Pro 5G, 256GB, 8GB RAM, Dual SIM, Moonlight White', 2699, 'XIAOMI 11T PRO','Dual SIM','6.67','1080 x 2400','256', '8', 'Octa Core', 'Qualcomm Snapdragon 888 5nm', '3', 'Tripla', '108MP (Wide) f1.75, 7P Lens, EIS, AF, 2.1μm 9-in-1 Super Pixel + 8MP (Ultra-Wide) f2.2, FOV 120º + 5MP (TeleMacro) f2.4, AF (3cm-7cm)', '16MP f2.45, 1.0μm pixel size, 1.0μm f/2.45', 'Da', 'Nu', '5000', 'Adaptor, Cablu USB tip C, Alimentare de 120W', 'Alb', '204', '24', 13, '2022-12-13 21:40:13'),
(167, '1', 'Telefon XIAOMI 11T 5G, 256GB, 8GB RAM, Dual SIM, Meteorite Gray', 2138, 'XIAOMI 11T','Dual SIM','6.67','1080 x 2400','256', '8', 'Octa Core', 'MediaTek Dimensity 1200 6nm', '3', 'Tripla', '108MP f1.75, 7P Lens, EIS, AF, 2.1μm 9-in-1 Super Pixel + 8MP (Ultra-Wide) f2.2, FOV 120º + 5MP (TeleMacro) f2.4, AF (3cm-7cm)', '16MP f2.45, 1.0μm pixel size, 1.0μm f/2.45', 'Da', 'Nu', '5000', 'Adaptor, Cablu USB tip C, Alimentator de 67W', 'Gri', '203', '24', 13, '2022-12-13 21:43:02'),
(168, '1', 'Telefon XIAOMI 11 Lite 5G NE, 128GB, 8GB RAM, Dual SIM, Peach Pink', 1599, 'XIAOMI 11 LITE 5G NE','Dual SIM','6.55','2400 x 1080','128', '8', 'Octa Core', 'Qualcomm Snapdragon 778G 6nm, Qualcomm Kryo 670', 'Pana la 2.4GHz', 'Tripla', '64MP f/1.79, 6P lens, 1/1.97", 0.7µm, 4-in-1 Super Pixel + 8MP (Ultra Wide-Angle) FOV 119°, f/2.2, 1.4", 1.12µm, 5P Lens + 5MP (TeleMacro) f/2.4, Contrast AF (3cm-7cm), 1.5", 1.12µm, 4P Lens', '20MP, f/2.24, Night mode, AI Beautify, Time-lapse selfie', 'Da', 'Nu', '4250', 'Adaptor incarcare 33W, Cablu USB Type-C', 'Roz', '158', '24', 13, '2022-12-13 21:45:41'),
(169, '1', 'Telefon XIAOMI Redmi Note 10 Pro, 64GB, 6GB RAM, Dual SIM, Glacier Blue', 1099, 'REDMI NOTE 10 PRO','Dual SIM','6.67','1080 x 2400','64', '4', 'Octa Core', 'Qualcomm Snapdragon 732G (8 × Kryo 470) 8nm', '2.3', 'Cvadrupla', '108MP (Wide) f/1.9, 1/1.52", 2.1µm, 9-in-1 Super Pixel, 6P lens, PDAF + 8MP (Ultrawide) f/2.2, FOV 118° + 5MP (Telemacro), f/2.4, AF + 2 MP (Depth), f/2.4', '16MP, f/2.45, 1 µm, Rezolutie imagine: 4608 x 3456 pixeli, Rezolutie video 1920 x 1080 pixeli, 30 fps', 'Da', 'Nu', '5020', ' ', 'Albastru', '193', '24', 13, '2022-12-13 21:47:12'),
(170, '1', 'Telefon XIAOMI Redmi Note 11, 128GB, 6GB RAM, Dual SIM, Star Blue', 1099, 'REDMI NOTE 11','Dual SIM','6.43','2400 x 1080','128', '8', 'Octa Core', 'Snapdragon 680 6nm', 'Pana la 2.4', 'Cvadrupla', '50MP (Wide) f/1.8 + 8MP (ultra-Wide) f/2.2, FOV 118° + 2MP (Macro) f/2.4 + 2MP (Depth) f/2.4', '13MP f/2.4, Video 1080p 1920x1080 | 30fps, 720p 1280x720 | 30fps', 'Da', 'Nu', '5000', 'Adaptor 33W, Cablu USB Type C', 'Albastru deschis', '179', '24', 13, '2022-12-13 21:50:01'),
(171, '1', 'Telefon XIAOMI Redmi 9T, 128GB, 4GB RAM, Dual SIM, Carbon Grey', 1019, 'REDMI 9T','Dual SIM','6.53',' ','128', '4', 'Octa Core', 'Qualcomm Snapdragon 662 11nm, Qualcomm Kryo 260, 3rd gen Qualcomm AI Engine', 'Pana la 2.0GHz', 'Cvadrupla', '48MP 1.6μm 4-in-1 Super Pixel, f/1.79, 0.8μm, Senzor 1/2”, 0.8μm, 6P lens, AF + 8MP (Ultra-Wide Angle), FOV 120°, f/2.2 + 2MP, (Macro), 1.75μm, f/2.4, FF + 2MP, (Depth), 1.75μm, f/2.4', '8MP, 1.12μm, f/2.05', 'Da', 'Nu', '6000', ' ', 'Gri', '198', '24', 13, '2022-12-13 21:52:18'),
(172, '1', 'Telefon XIAOMI Redmi Note 11, 128GB, 4GB RAM, Dual SIM, Star Blue', 983, 'REDMI NOTE 11','Dual SIM','6.43','2400 x 1080','128', '4', 'Octa Core', 'Snapdragon 680 6nm', 'Pana la 2.4', 'Cvadrupla', '50MP (Wide) f/1.8 + 8MP (ultra-Wide) f/2.2, FOV 118° + 2MP (Macro) f/2.4 + 2MP (Depth) f/2.4', '13MP f/2.4, Video 1080p 1920x1080 | 30fps, 720p 1280x720 | 30fps', 'Da', 'Nu', '5000', 'Adaptor 33W, Cablu USB Type C', 'Albastru deschis', '179', '24', 13, '2022-12-13 21:55:03'),
(173, '1', 'Telefon XIAOMI Redmi 10, 64GB, 4GB RAM, Dual SIM, Carbon Gray', 799, 'REDMI 10','Dual SIM','6.5','1080 x 2400','64', '4', 'Octa Core', 'MediaTek Helio G88 12nm', '2x Arm Cortex 2.0GHz + 6x Arm Cortex 1.8GHz', 'Cvadrupla', '50MP f1.8 + 8MP (Ultra-Wide) f2.2, FOV 120 + 2MP (Macro) f2.4 + 2MP (Depth) f2.4', '8MP, F2.0', 'Da', 'Nu', '5000', ' ', 'Gri', '181', '24', 13, '2022-12-13 21:57:21'),
(174, '1', 'Telefon XIAOMI Redmi 9AT, 32GB, 2GB RAM, Dual SIM, Granite Gray', 518, 'REDMI 9AT','Dual SIM','6.53','720 x 1600','32', '2', 'Octa Core', 'MediaTek Helio G25, 12nm', '2.0', 'Single', '13MP f2/2, AF, FOV 74°', '5MP, f2.2, FOV 83°', 'Nu', 'Nu', '5000', ' ', 'Gri', '194', '24', 13, '2022-12-13 21:59:49'),
(175, '1', 'Telefon XIAOMI Redmi 9C NFC, 32GB, 2GB RAM, Dual SIM, Midnight Grey', 499, 'REDMI 9C NFC','Dual SIM','6.53','1600 x 720','32', '2', 'Octa Core', 'Cortex-A53 MediaTek Helio G35 12 nm', '4 x A53 @ 2.3 GHz + 4 x A53 @ 1.8 GHz', 'Duala', '13MP (Wide) f/1.8, 1/3.1", 1.12µm, PDAF + 2MP (Depth) f/2.4', '5MP, Portrait selfies, Palm Shutter AI portrait mode, Digital zoom, HDR, Touch focus, Recunoastere faciala', 'Nu', 'Nu', '5000', ' ', 'Gri', '196', '24', 13, '2022-12-13 22:02:13'),
(176, '1', 'Telefon XIAOMI Redmi 9A, 32GB, 2GB RAM, Dual SIM, Green', 479, 'REDMI 9A','Dual SIM','6.53','1600 x 720','32', '2', 'Octa Core', 'MediaTek Helio G25, 12nm', '8 x A53 @ 2.0GHz', 'Single', '13MP, F2.2, AF, FOV 74°', '5MP, f/2.2, 1.12μm, FOV 83°, AI beautify 5.0, AI portrait mode, HDR, Screen flash, Selfie timer, Face recognition, Portrait selfies, Palm shutter', 'Da', 'Nu', '5000', ' ', 'Verde', '194', '24', 13, '2022-12-13 21:59:49'),
(177, '1', 'Telefon REALME C30, 32GB, 3GB RAM, Dual Sim, Denim Black', 546, 'REALME C30','Dual SIM','6.5','1600 x 720','32', '3', 'Octa Core', 'T612, UMS9230H, 12nm', '2x A75 1.82G + 6x A55 1.82G', 'Single', '8MP, f/2.0, Lens 4P, Sensor Sizes 1/4“, Pixel size 1.12μm, AF', '5MP, f/2.2, FOV 77°, CMOS, Sensor Sizes 1/5”, Pixel size 1.12μm, Lens 3P, FF, Rezolutie foto 2592x1944 pixeli, Rezolutie video 720p+', 'Da', 'Nu', '5000', ' ', 'Negru', '182', '24', 15, '2022-12-14 19:01:10'),
(178, '1', 'Telefon REALME C31, 64GB, 4GB RAM, Dual Sim, Dark Green', 628, 'REALME C31','Dual SIM','6.51','1600 x 720','64', '4', 'Octa Core', 'Unisoc T612 12nm', 'Pana la 1.82', 'Tripla', '13MP f2.2 FOV 81.3° 5P Lens, AF + 2MP (Black&White) f2.8 FOV 60° 2P Lens, FF + 0.3MP (Macro) f2.4 FOV 88.8°, FF', '5MP, FOV 76.6°, f2.2, senzor CMOS, 3P Lens, FF, HDR, Beauty Mode, Face Recognition, Filter', ' ', ' ', '5000', ' ', 'Verde inchis', '197.3', '24', 15, '2022-12-14 19:03:23'),
(179, '1', 'Telefon REALME 9i, 128GB, 4GB RAM, Dual SIM, Prism Black', 829, 'REALME 9i','Dual SIM','6.6','2412 x 1080','128', '4', 'Octa Core', 'Qualcomm Snapdragon 680 6nm', 'Pana la 2.7', 'Tripla', '50MP f/1.8, 5P lens, PDAF + 2MP (Macro) f/2.4 4cm + 2MP (B&W Lens) f/2.4', '16MP f/2.1, 5P lens, Rezolutie 1080p, Night Mode, Panoramic view, Timelapse, Portrait Mode, AI Beauty', 'Da', 'Nu', '5000', 'Incarcator 33W, Cablu USB Type C', 'Negru', '190', '24', 15, '2022-12-14 19:06:01'),
(180, '1', 'Telefon REALME C35, 128GB, 4GB RAM, Dual Sim, Glowing Black', 849, 'REALME C35','Dual SIM','6.6','2408 x 1080','128', '4', 'Octa Core', 'Unisoc T616 12nm', 'Pana la 2.0', 'Tripla', '50MP f/1.8, 5P lens + Macro f2.4, 4cm + Black&White f2.8', '8MP, f2.0, 5P Lens, Filter, Time lapse, HDR, Rezolutie video 720p', 'Da', 'Nu', '5000', 'Incarcator 18W, Cablu USB Type C', 'Negru', '189', '24', 15, '2022-12-14 19:09:10'),
(181, '1', 'Telefon REALME 9 Pro+, 128GB, 6GB RAM, Dual SIM, Aurora Green', 1399, 'REALME 9 PRO+','Dual SIM','6.6','1080 x 2400','128', '6', 'Octa Core', 'MediaTek Dimensity 920 5G 6nm', 'Pana la 2.5', 'Tripla', '50MP f1.8, 23.6mm, FOV: 84.4°, 6P Lens + 2MP (Macro) f2.4, 21.8mm, FOV: 88.8°, 3P Lens + 8MP (Ultra-Wide angle), f2.2, 15.4mm, FOV: 119°, 5P Lens', '16MP, f2.4, FOV: 78°, Video 1080P/30fps, Moduri Ultra Steady Video, Portrait Mode, Timelaps, Panoramic view, Beauty Mode, HDR, Face-Recognition, Filter, Night Mode, Bokeh Effect Control, Street Mode', 'Da', 'Nu', '4500', ' ', 'Verde', '182', '24', 15, '2022-12-14 19:12:31'),
(182, '1', 'Telefon REALME 9 Pro, 128GB, 6GB RAM, Dual SIM, Midnight Black', 1199, 'REALME 9 PRO','Dual SIM','6.6','2412 x 1080','128', '6', 'Octa Core', 'Snapdragon 695 SM6375 64bits 6nm', '2x Kryo Gold 2.2GHz + 6x Kryo Silver 1.8GHz', 'Tripla', '64MP f1.79 FOV 79°, 25.18mm, Lens 6P, 1/2", pixel size 0.70μm, PDAF + 8MP (Wide-angle) f2.2, FOV 119.9°, 15.62mm, Lens 5P, 1/4", pixel size 1.12μm, FF + 2MP (Macro) f2.4, FOV 88°, 21.88mm, Lens 3P, 1/5", pixel size 1.75μm, FF', '16MP, Sony IMX471-AAJH5-C, f2.05, FOV 79.3°, Senzor CMOS, 1/3.09", Pixel size 1.00μm, Lens 5P, FF, Rezolutie foto 4608x3456, Rezolutie video 1080p @ 30fps, EIS & EIS PRO', 'Da', 'Nu', '5000', ' ', 'Negru', '195', '24', 15, '2022-12-14 19:15:21'),
(183, '1', 'Telefon REALME 9 5G, 128GB, 4GB RAM, Dual SIM, Meteor Black', 999, 'REALME 9 5G','Dual SIM','6.6','2412 x 1080','128', '4', 'Octa Core', 'Snapdragon 695 5G 6nm', 'Kryo Gold 2.2GHz x2 + Kryo Silver 1.8GHz x6', 'Tripla', '50MP (Ultra HD) FOV: 77°, F1.8, 5P Lens, 1/2.76" + Camera B&W FOV: 88.8°, F2.4, 3P Lens + Camera Macro 4cm FOV: 88.8°, F2.4, 3P Lens', '16MP FOV: 79.3°, F2.05, 5P Lens, Slow Motion, Filter, Dual-View, Film, Time-Lapse, Starry', 'Da', 'Nu', '5000', 'Incarcator 18W, Cablu USB Type C', 'Negru', '191', '24', 15, '2022-12-14 19:18:58'),
(184, '1', 'Telefon REALME GT neo 3, 256GB, 12GB RAM, Dual SIM, Nitro Blue', 2850, 'REALME GT NEO 3','Dual SIM','6.7','2412 x 1080','256', '12', 'Octa Core', 'Dimensity 8100 5G Processor 5nm + AI APU5.0', '2.85', 'Tripla', '50MP (Sony IMX766 OIS) 23.6mm, FOV: 84.4°, f/1.88, Lens: 6P, 1/1.56 + 8MP (Ultra-wide) FOV 119.7°, 15.4mm, f/2.25, Lens: 5P + 2MP (Macro) 21.8 mm, FOV: 88.8°, f/2.4, Lens: 3P', '16MP Senzor Samsung S5K3P9, FOV: 82.3°, f/2.45, Dual-view Video, Rezolutie video 1080p, Panoramic View, Portrait Mode, Super Nightscape, Time-lapse+', 'Da', 'Nu', '5000', 'Incarcator 11V/7.3A (MAX), USB-C', 'Albastru', '188', '24', 15, '2022-12-14 19:21:08'),
(185, '1', 'Telefon REALME GT 2 5G, 256GB, 12GB RAM, Dual Sim, Paper Green', 2339, 'REALME GT 2','Dual SIM','6.62','2400 x 1080','256', '12', 'Octa Core', 'Snapdragon 888 SM8350AB 5nm', 'Pana la 2.84, Cortex X1 2.84GHz x1 Cortex A78 2.4GHz x3 Cortex A55 1.8GHz x4', 'Tripla', '50MP F1.8, FOV 84.4, 23.6mm, OIS, 6P Lens, 1/1.56", 1.0um, PDAF + 8MP (Wide-Angle) f2.2, FOV 119.9, 15.7mm, 5P Lens, 1/4", 1.12um, FF + 2MP (Micro) f2.4, FOV 88.8, 21.9mm, 3P Lens, 1/5", 1.75um, FF', '16MP IMX471, f2.5, FOV 78, CMOS, 1/3.09“, 1.0um, FF, Rezolutie foto 3456 x 4608, Rezolutie video 1080p', 'Da', 'Nu', '5000', ' ', 'Verde', '194.5', '24', 15, '2022-12-14 19:24:12'),
(186, '1', 'Telefon REALME GT Master 5G, 256GB, 8GB RAM, Dual Sim, Voyage Gray', 1450, 'GT','Dual SIM','6.43','2400 x 1080','256', '8', 'Octa Core', 'Qualcomm Snapdragon 778G', ' ', 'Tripla', ' ', 'Da', 'Da', 'Nu', '4300', ' ', 'Gri', ' ', '24', 15, '2022-12-14 19:27:31'),
(187, '1', 'Telefon REALME 8i, 128GB, 4GB RAM, Dual Sim, Space Black', 740, 'REALME 8I','Dual SIM','6.6',' ','128', '4', 'Octa Core', 'Helio G96', 'Pana la 2.05', 'Tripla', '50MP f/1.8, 5P lens, PDAF + 2MP (Macro) f2.4, 4cm + 2MP (Black & White) f2.4', '16MP f2.05, 5P Lens, Ultra Steady Video, Night Mode, Panoramic view, Timelapse, Portrait Mode, HDR, AI Scene Recognition, AI Beauty, Filter, Chroma Boost, Slow Motion, Video 1080P', 'Da', 'Nu', '5000', 'Cablu USB Type-C, adaptor incarcare 18W', 'Negru', '194', '24', 15, '2022-12-14 19:30:01'),
(188, '1', 'Telefon REALME C11 (2021), 32GB, 2GB RAM, Dual Sim, Lake Blue', 387, 'REALME C11 (2021)','Dual SIM','6.5','1600 x 720','32', '2', 'Octa Core', 'SC9863A', 'Pana la 1.6', 'Single', '8MP f/2.0, 4P lens, AF', '5MP, F2.2, 3P Lens, Panoramic view, Portrait Mode, Expert, Timelapse, HDR, Beauty, Filter', ' ', ' ', '5000', 'Cablu MicroUSB, Adaptor incarcare', 'Albastru', '190', '24', 15, '2022-12-14 19:32:15'),
(189, '1', 'Telefon REALME C11 (2021), 32GB, 2GB RAM, Dual Sim, Iron Grey', 381, 'REALME C11 (2021)','Dual SIM','6.5','1600 x 720','32', '2', 'Octa Core', 'SC9863A', 'Pana la 1.6', 'Single', '8MP f/2.0, 4P lens, AF', '5MP, F2.2, 3P Lens, Panoramic view, Portrait Mode, Expert, Timelapse, HDR, Beauty, Filter', ' ', ' ', '5000', 'Cablu MicroUSB, Adaptor incarcare', 'Gri', '190', '24', 15, '2022-12-14 19:35:09'),
(190, '1', 'Telefon OPPO A96, 128GB, 6GB RAM, Dual SIM, Sunset Blue', 1059, 'OPPO A96','Dual SIM','6.59','2412 x 1080','128', '6', 'Octa Core', 'Qualcomm Snapdragon 680', 'Pana la 2,4 GHz', 'Duala', '50MP, f/1.8, FOV 77°, obiectiv 5P, AF + 2MP (Bokeh), f/2.4, FOV 88.8°, obiectiv 3P, FF', '16MP, f/2.0, FOV 79.3°, obiectiv 5P, Video 1080p', 'Da', 'Nu', '5000', 'Cablu, Incarcator', 'Albastru', '191', '24', 16, '2022-12-14 19:41:31'),
(191, '1', 'Telefon OPPO A96, 128GB, 6GB RAM, Dual SIM, Starry Black', 989, 'OPPO A96','Dual SIM','6.59','2412 x 1080','128', '6', 'Octa Core', 'Qualcomm Snapdragon 680', 'Pana la 2,4 GHz', 'Duala', '50MP, f/1.8, FOV 77°, obiectiv 5P, AF + 2MP (Bokeh), f/2.4, FOV 88.8°, obiectiv 3P, FF', '16MP, f/2.0, FOV 79.3°, obiectiv 5P, Video 1080p', 'Da', 'Nu', '5000', 'Cablu, Incarcator', 'Negru', '191', '24', 16, '2022-12-14 19:43:22'),
(192, '1', 'Telefon OPPO Reno7 Lite 5G, 128GB, 8GB RAM, Dual SIM, Rainbow Spectrum', 1749, 'OPPO RENO7 LITE','Dual SIM','6.43','2400 x 1080','128', '8', 'Octa Core', 'Qualcomm Snapdragom 695 (SDM695)', '2x2.2 GHz Kryo 660 Gold + 6x1.7 GHz Kryo 660 Silver', 'Tripla', '64MP + 2MP + 2MP', '16MP (Wide) f/2.4, 27mm, 1.0µm, Rezolutie video 1080p@30fps', 'Da', 'Nu', '4500', ' ', 'Multicolor', '173', '24', 16, '2022-12-14 19:45:08'),
(193, '1', 'Telefon OPPO Reno7, 128GB, 8GB RAM, Dual SIM, Sunset Orange', 1399, 'OPPO RENO7 4G','Dual SIM','6.43','2400 x 1080','128', '8', 'Octa Core', 'Snapdragon 680, Kryo 265', '2.4, 1.9', 'Tripla', '64MP + 2MP + 2MP', '32MP, Sony IMX709 1/2.74", 0.8um, f/2.4, FOV 85°, 5P lens, FF, Photo, video, panorama, portrait, night scene, time-lapse photography, beauty selfie', 'Da', 'Nu', '4500', ' ', 'Portocaliu', '175', '24', 16, '2022-12-14 19:48:01'),
(194, '1', 'Telefon OPPO Reno7, 128GB, 8GB RAM, Dual SIM, Cosmic Black', 1399, 'OPPO RENO7 4G','Dual SIM','6.43','2400 x 1080','128', '8', 'Octa Core', 'Snapdragon 680, Kryo 265', '2.4, 1.9', 'Tripla', '64MP + 2MP + 2MP', '16MP (Wide) f/2.4, 27mm, 1.0µm, Rezolutie video 1080p@30fps', 'Da', 'Nu', '4500', ' ', 'Negru', '175', '24', 16, '2022-12-14 19:51:32'),
(195, '1', 'Telefon OPPO A54s, 128GB, 4GB RAM, Dual SIM, Crystal Black', 649, 'OPPO A54S','Dual SIM','6.52','1600 x 720','128', '4', 'Octa Core', 'MediaTek Helio G35', 'Pana la 2.3', 'Tripla', '50MP f/2.2, FOV 80°, 5P lens, AF + 2MP (Mono) f/2.4, FOV 88.8°, 3P lens, FF + 2MP (Macro) f/2.4, FOV 88.8°, 3P lens, FF', '8MP f/2.0, FOV79°, 5P Lens, Rezolutie video 1080P@30fps, 720P@30fps', ' ', ' ', '5000', ' ', 'Negru', '190', '24', 16, '2022-12-14 19:55:12'),
(196, '1', 'Telefon NOKIA G11, 32GB, 3GB RAM, Dual SIM, Charcoal', 563, 'NOKIA G11','Dual SIM','6.5','1600 x 720','32', '3', 'Octa Core', 'Unisoc T606', ' ', 'Tripla', '13MP + 2MP (Macro) + 2MP (Depth)', '8MP', ' ', ' ', '5050', 'Incarcator 10W', 'Gri', '189', '24', 17, '2022-12-14 20:13:43'),
(197, '1', 'Telefon NOKIA G21, 64GB, 4GB RAM, Dual SIM, Nordic Blue', 647, 'NOKIA G21','Dual SIM','6.5','1600 x 720','64', '4', 'Octa Core', 'Unisoc T606', ' ', 'Tripla', '50MP Main 1/2.76“ CMOS, 0.64um, 5P lens, f/1.8 + 2MP (Macro) + 2MP (Depth)', '8MP', ' ', ' ', '5050', 'Incarcator 10W', 'Albastru', '190', '24', 17, '2022-12-14 20:16:03'),
(198, '1', 'Telefon NOKIA G50 5G, 128GB, 4GB RAM, Dual SIM, Ocean Blue', 899, 'NOKIA G50','Dual SIM','6.82','1560 x 720','128', '4', 'Octa Core', 'Qualcomm SM4350 Snapdragon 480 5G', '2 x 2.0 GHz Kryo 460 + 6 x 1.8 GHz Kryo 460', 'Tripla', '48MP (Wide) f/1.8, AF, PDAF, AI + 5 MP (Ultrawide), 2MP (Depth)', '8MP (Wide) f/2.0, video: 1080p@30fps', 'Da', 'Nu', '5000', ' ', 'Albastru', '220', '24', 17, '2022-12-14 20:18:21'),
(199, '1', 'Telefon NOKIA G60 5G, 128GB, 6GB RAM, Dual SIM, Black', 1399, 'NOKIA G60','Dual SIM','6.58','2408 x 1080','128', '8', 'Octa Core', '	Snapdragon 695 5G 6 nm', '2.2', 'Tripla', '	50MP 0.7µm (1.4µm 4-in-1), f/1.8, 1/2.5” + 5MP (Ultra-Wide) f/2.2, 1/5” + 2MP (Depth) f/2.4, 1/5”', '8MP, 1.12µm, f/2.0, 1/4”', 'Da', 'Nu', '4500', 'USB-C, Nu contine adaptor priza', 'Negru', '190', '24', 17, '2022-12-14 20:21:33'),
(200, '1', 'Telefon NOKIA XR20, 128GB, 6GB RAM, Dual SIM, Ultra Blue', 2259, 'NOKIA XR20','Dual SIM','6.67','1080 x 2400','128', '6', 'Octa Core', 'Qualcomm Snapdragon 480 5G', ' ', 'Duala', '48MP, GM1st, f/1.79, 1/2.25, 0.8μm, AF + 13MP (Ultrawide) 3L6, f2.4, 1/3”, 1.12 μm, FOV 123°, FF', '8MP FF, 4H7, f2.0, 1/4", 1.12μm', 'Da', 'Nu', '4630', ' ', 'Negru', '248', '24', 17, '2022-12-14 20:24:54'),
(201, '1', 'Telefon NOKIA X20 5G, 128GB, 6GB RAM, Dual SIM, Nordic Blue', 1499, 'NOKIA X20','Dual SIM','6.67','2400 x 1080','128', '6', 'Octa Core', 'Qualcomm SM4350 Snapdragon 480 5G (8 nm)', '2 x 2.0 GHz Kryo 460 & 6 x 1.8 GHz Kryo 460', 'Cvadrupla', '64MP (Wide) AF + 5MP (Ultra-Wide Angle) FF + 2MP (Macro) +2MP (Depth)', '32MP, Rezolutie video: 1920 x 1080 pixeli@30fps', 'Da', 'Nu', '4470', ' ', 'Albastru', '220', '24', 17, '2022-12-14 20:27:02'),
(202, '1', 'Telefon NOKIA 3.4, 64GB, 3GB RAM, Dual SIM, Fjord', 599, 'NOKIA 3.4','Dual SIM','6.39','720 x 1520','64', '3', 'Octa Core', 'Chipset Qualcomm SM4250 Snapdragon 460, ARM Cortex-A73', '1.8', 'Tripla', '13MP, f/2.0, 1.12 microni + 2MP (Depth) + 5MP (Ultra-Wide)', '8MP, Senzor CMOS, f/2.4, Rezolutie foto: 3264 x 2448 pixeli, Rezolutie video: 1920 x 1080 pixeli@30fps, Deblocare biometrica prin recunoastere faciala - AI', ' ', ' ', '4000', ' ', 'Albastru deschis', '180', '24', 17, '2022-12-14 20:30:01');


-- --------------------------------------------------------

--
-- Table structure for table `sitedetail`
--

CREATE TABLE `sitedetail` (
  `tempId` int(11) NOT NULL,
  `systemName` varchar(21) NOT NULL,
  `email` varchar(35) NOT NULL,
  `contact1` bigint(21) NOT NULL,
  `contact2` bigint(21) DEFAULT NULL COMMENT 'Optional',
  `address` text NOT NULL,
  `dateTime` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sitedetail`
--

INSERT INTO `sitedetail` (`tempId`, `systemName`, `email`, `contact1`, `contact2`, `address`, `dateTime`) VALUES
(1, 'xMAG', 'xmagonline@gmail.com', 0769101102, 0256101102, 'Bulevardul Liviu Rebreanu<br> Timisoara', '2022-12-14 22:30:01');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(21) NOT NULL,
  `username` varchar(21) NOT NULL,
  `firstName` varchar(21) NOT NULL,
  `lastName` varchar(21) NOT NULL,
  `email` varchar(35) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `userType` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=user\r\n1=admin',
  `password` varchar(255) NOT NULL,
  `joinDate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `firstName`, `lastName`, `email`, `phone`, `userType`, `password`, `joinDate`) VALUES
(1, 'xmag_david', 'David', 'Xmag', 'xmagadmin@gmail.com', 0769101102, '1', '$2y$10$AAfxRFOYbl7FdN17rN3fgeiPu/xQrx6MnvRGzqjVHlGqHAM4d9T1i', '2022-12-14 22:41:34');

-- --------------------------------------------------------

--
-- Table structure for table `viewcart`
--

CREATE TABLE `viewcart` (
  `cartItemId` int(11) NOT NULL,
  `phoneId` int(11) NOT NULL,
  `itemQuantity` int(100) NOT NULL,
  `userId` int(11) NOT NULL,
  `addedDate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`categorieId`);
ALTER TABLE `categories` ADD FULLTEXT KEY `categorieName` (`categorieName`,`categorieDesc`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`contactId`);

--
-- Indexes for table `contactreply`
--
ALTER TABLE `contactreply`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `deliverydetails`
--
ALTER TABLE `deliverydetails`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `orderId` (`orderId`);

--
-- Indexes for table `orderitems`
--
ALTER TABLE `orderitems`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`orderId`);

--
-- Indexes for table `phone`
--
ALTER TABLE `phone`
  ADD PRIMARY KEY (`phoneId`);
ALTER TABLE `phone` ADD FULLTEXT KEY `phoneName` (`phoneName`,`phoneModel`);

--
-- Indexes for table `sitedetail`
--
ALTER TABLE `sitedetail`
  ADD PRIMARY KEY (`tempId`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `viewcart`
--
ALTER TABLE `viewcart`
  ADD PRIMARY KEY (`cartItemId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `categorieId` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `contactId` int(21) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contactreply`
--
ALTER TABLE `contactreply`
  MODIFY `id` int(21) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `deliverydetails`
--
ALTER TABLE `deliverydetails`
  MODIFY `id` int(21) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orderitems`
--
ALTER TABLE `orderitems`
  MODIFY `id` int(21) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `orderId` int(21) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `phone`
--
ALTER TABLE `phone`
  MODIFY `phoneId` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT for table `sitedetail`
--
ALTER TABLE `sitedetail`
  MODIFY `tempId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `viewcart`
--
ALTER TABLE `viewcart`
  MODIFY `cartItemId` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

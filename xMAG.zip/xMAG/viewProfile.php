<!DOCTYPE HTML>
<html lang="en">
<head>
    <link rel="stylesheet" href="/xMAG/assets/css/style6.css">
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
 

    <title>Profilul meu </title>
    <link rel = "icon" href ="img/xmag_icon.png" type = "image/x-icon">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">
    <style>
        *{
            font-family: Bahnschrift;
        }
        body {
            background-color: #EFFFFF;
        }
        .rows {
            margin-right: 150px;
            margin-top: 73px;
        }
        .footer.container-fluid {

          position: relative;
        }

        #notfound {
        position: relative;
        height: 89vh;
        background-color: #1bbca3;
        }

        #notfound .notfound {
        position: absolute;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%);
        }

        .notfound {
        max-width: 410px;
        width: 100%;
        text-align: center;
        }

        .notfound .notfound-404 {
        height: 280px;
        position: relative;
        z-index: -1;
        }

        .notfound .notfound-404 h1 {
        font-family: 'Montserrat', sans-serif;
        font-size: 230px;
        margin: 0px;
        font-weight: 900;
        position: absolute;
        left: 50%;
        transform: translateX(-50%);
        background: url('img/bg.jpg') no-repeat;
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-size: cover;
        background-position: center;
        }


        .notfound h2 {
        font-family: 'Montserrat', sans-serif;
        color: #000;
        font-size: 24px;
        font-weight: 700;
        text-transform: uppercase;
        margin-top: 0;
        }


        .notfound a {
        font-family: 'Montserrat', sans-serif;
        font-size: 14px;
        text-decoration: none;
        text-transform: uppercase;
        background: #1bbca3;
        display: inline-block;
        padding: 15px 30px;
        border-radius: 40px;
        color: #fff;
        font-weight: 700;
        box-shadow: 0px 4px 15px -5px #1bbca3;
        }


        @media only screen and (max-width: 767px) {
            .notfound .notfound-404 {
            height: 142px;
            }
            .notfound .notfound-404 h1 {
            font-size: 112px;
            }
        }

        .upload-btn-wrapper {
        position: relative;
        overflow: hidden;
        display: inline-block;
        }

        button.btn.upload {
        border: 2px #1bbca3;
        color: white;
        background-color: #1bbca3;
        border-radius: 4px;
        padding: 3px 8px;
        font-size: 10px;
        font-weight: bold;
        }

        .upload-btn-wrapper input[type=file] {
        font-size: 100px;
        position: absolute;
        left: 0;
        top: 0;
        opacity: 0;
        }
        .btn-primary1 {
        background: linear-gradient(to right, #2ae0c4 0%, #1bbca3 100%);
        border-style: none;
        color: white;
        box-shadow: none;
        }

        .btn-primary1:hover {
            background: linear-gradient(to right, #1bbca3 0%, #334240 100%);
            border-style: none;
        color: white;
        box-shadow: none;
        }
    </style>

</head>
<body>
    <?php include 'partials/_dbconnect.php';?>
    <?php require 'partials/_nav.php' ?>
    <?php
        if($loggedin) {
    ?>
    
    <div class="container">
        <?php 
            $sql = "SELECT * FROM users WHERE id='$userId'"; 
            $result = mysqli_query($conn, $sql);
            $row=mysqli_fetch_assoc($result);
            $username = $row['username'];
            $firstName = $row['firstName'];
            $lastName = $row['lastName'];
            $email = $row['email'];
            $phone = $row['phone'];
            $userType = $row['userType'];
            if($userType == 0) {
                $userType = "Utilizator";
            }
            else {
                $userType = "Administrator";
            }

        ?>
        <div class="rows">
            <div class="jumbotron p-3 mb-3" style="display: flex; justify-content: center; width: 28%; border-radius: 23px; border-color: black; margin: 0 auto;">
                <div class="user-info">
                    <img class="rounded-circle mb-3 bg-dark" style="text-align: center;" src="img/person-<?php echo $userId; ?>.jpg" onError="this.src = 'img/.jpg'" style="width:215px;height:215px;padding:1px;">
                    <ul class="meta list list-unstyled" style="text-align:center;">
                        <b><li class="username my-2" style="background-color: white; border-radius: 5px;";><a href="viewProfile.php" style="color: #1bbca3">@<?php echo $username ?></a></li></b>
            
                    </ul>
                    <form action="partials/_manageProfile.php" method="POST">
                        <small>Șterge imaginea: </small><button type="submit" class="btn btn-primary1 mx-2" name="removeProfilePic" style="font-size: 12px;padding: 3px 8px;border-radius: 4px;">Șterge</button>
                    </form>
                    <form action="partials/_manageProfile.php" method="POST" enctype="multipart/form-data" style="margin-top: 7px;">
                        <div class="upload-btn-wrapper">
                            <small>Schimbă imaginea:</small>
                            <button class="btn upload">Alege</button>
                            <input type="file" name="image" id="image" accept="image/*">
                            
                        </div> 
                        <button type="submit" name="updateProfilePic" class="btn btn-primary1 mx-2" style="font-size: 12px;padding: 3px 8px;border-radius: 4px;">Actualizează</button>
                    </form>
                    
                    <ul class="meta list list-unstyled" style="text-align:center;">
                        <li>________________________________</li>
                        <b><li class="name"><?php echo $firstName." ".$lastName; ?></b>
                            <label class="label label-info">(<?php echo $userType ?>)</label>
                        </li>
                        <b><li class="email"><?php echo $email ?></li></b>
                        <li>________________________________</li>
                        <li class="my-2"><a href="partials/_logout.php"><button class="btn btn-primary1 mx-2" style="font-size: 15px;padding: 3px 8px;">Deconectează-te</button></a></li>
                    </ul>
                </div>
            </div>
            <div class="content-panel mb-3" style="display: flex;justify-content: center;">
                <div class="border p-3" style="border: 2px solid rgba(0, 0, 0, 0.1); border-radius: 1.1rem; background-color: aliceblue;">
                    <h2 class="title text-center"><b>Profilul meu</b><span class="pro-label label label-warning"> (<?php echo $userType ?>)</span></h2>
                
                    <form action="partials/_manageProfile.php" method="post">
                        <div class="form-group">
                            <b><label for="username">Nume de utilizator:</label></b>
                            <input class="form-control" id="username" name="username" type="text" disabled value="<?php echo $username ?>">
                        </div>
                        <div class="form-row">
                        <div class="form-group col-md-6">
                            <b><label for="firstName">Nume:</label></b>
                            <input type="text" class="form-control" id="firstName" name="firstName" required value="<?php echo $firstName ?>">
                        </div>
                        <div class="form-group col-md-6">
                            <b><label for="lastName">Prenume:</label></b>
                            <input type="text" class="form-control" id="lastName" name="lastName" required value="<?php echo $lastName ?>">
                        </div>
                        </div>
                        <div class="form-group">
                            <b><label for="email">Adresa de email:</label></b>
                            <input type="email" class="form-control" id="email" name="email" placeholder="Introduceți adresa de email" required value="<?php echo $email ?>">
                        </div>
                        <div class="form-row">
                            <div class="form-group  col-md-6">
                                <b><label for="phone">Număr de telefon:</label></b>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon">+40</span>
                                    </div>
                                    <input type="tel" class="form-control" id="phone" name="phone" placeholder="Introduceți un număr de telefon valid" required pattern="[0-9]{10}" maxlength="10" value="<?php echo $phone ?>">
                                </div>
                            </div>
                            <div class="form-group  col-md-6">
                                <b><label for="password">Parola:</label></b>    
                                <input class="form-control" id="password" name="password" placeholder="Introduceți parola" type="password" required minlength="4" maxlength="21" data-toggle="password">
                            </div>
                        </div>
                        <button type="submit" name="updateProfileDetail" class="btn btn-primary">Actualizează</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php
        }
        else {
            echo '<div id="notfound">
                <div class="notfound">
                    <div class="notfound-404">
                        <h1>Oops!</h1>
                    </div>
                    <h2>404 - Page not found</h2>
                    <a href="index.php">Mergi la pagina Acasă</a>
                </div>
            </div>';
        }
    ?>
    
    <?php include 'partials/_footer.php';?> 
    
    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>         
    <script src="https://unpkg.com/bootstrap-show-password@1.2.1/dist/bootstrap-show-password.min.js"></script>
    <script>
        $('#image').change(function() {
            var i = $(this).prev('button').clone();
            var file = ($('#image')[0].files[0].name).substring(0, 5) + "..";
            $(this).prev('button').text(file);
        });
    </script>
</body>

</html>

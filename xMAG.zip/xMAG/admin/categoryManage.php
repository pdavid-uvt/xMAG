
<style>
    .btn-primary {
        background: linear-gradient(to right, #2ae0c4 0%, #1bbca3 100%);
        border-style: none;
        box-shadow: none;
    }

    .btn-primary:hover {
        background: linear-gradient(to right, #1bbca3 0%, #334240 100%);
        border-style: none;
        box-shadow: none;
    }

    .btn-primary-cancel {
        background: linear-gradient(to right, #DC143C 0%, #FF0000 100%);
        border-style: none;
        color: white;
    }

    .btn-primary-cancel:hover {
        background: linear-gradient(to right, #FF0000 0%, #DC143C 100%);
        border-style: none;
		color: white;
    
    }
</style>

<div class="container-fluid" style="margin-top:98px">
    <div class="col-lg-12">
        <div class="row">
            <!-- FORM Panel -->
            <div class="col-md-4">
                <form action="partials/_categoryManage.php" method="post" enctype="multipart/form-data">
                    <div class="card">
                        <div class="card-header" style="background-color: rgb(111 202 203);">
                            <strong>Adăugare categorie nouă</strong>
                        </div>
                        <div class="card-body">
                            <div class="form-group">
                                <label class="control-label">Nume: </label>
                                <input type="text" class="form-control" name="name" required>
                            </div>
                            <div class="form-group">
                                <label class="control-label">Descriere: </label>
                                <input type="text" class="form-control" name="desc" required>
                            </div> 
                            <div class="form-group">
								<label for="image" class="control-label">Imagine:</label>
								<input type="file" name="image" id="image" accept=".jpg" class="form-control" required style="border:none;">
								<small id="Info" class="form-text text-muted mx-3">A se încărca un fișier .jpg!</small>
							</div>  
                        </div>  
                        <div class="card-footer">
                            <div class="row">
                                <div class="mx-auto">
                                    <button type="submit" name="createCategory" class="btn btn-primary mx-2"> Adăugare categorie </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <!-- FORM Panel -->
    
            <!-- Table Panel -->
            <div class="col-md-8 mb-3">
                <div class="card">
                    <div class="card-body">
                    <table class="table table-bordered table-hover mb-0">
                        <thead style="background-color: rgb(111 202 203);">
                        <tr>
                            <th class="text-center" style="width:7%;">ID Categorie</th>
                            <th class="text-center">Imagine categorie</th>
                            <th class="text-center" style="width:58%;">Descriere categorie</th>
                            <th class="text-center" style="width:18%;">Actiune element categorie</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php 
                            $sql = "SELECT * FROM `categories`"; 
                            $result = mysqli_query($conn, $sql);
                            while($row = mysqli_fetch_assoc($result)){
                                $catId = $row['categorieId'];
                                $catName = $row['categorieName'];
                                $catDesc = $row['categorieDesc'];

                                echo '<tr>
                                        <td class="text-center"><b>' .$catId. '</b></td>
                                        <td><img src="/xMAG/img/card-'.$catId. '.jpg" alt="Imagine pentru categorie" width="120px" height="70px"></td>
                                        <td>
                                            <p>Nume: <b>' .$catName. '</b></p>
                                            <p>Descriere: <b class="truncate">' .$catDesc. '</b></p>
                                        </td>
                                        <td class="text-center">
                                            <div class="row mx-auto" style="width:150px">
                                            <h5><em>&emsp;</em></h5>
                                            <button class="btn btn-primary mx-2" style="position: relative; font-size: 18px; padding: 3px 35px; bottom: 10px;" type="button" data-toggle="modal" data-target="#updateCat' .$catId. '">Editează</button>
                                            <form action="partials/_categoryManage.php" method="POST">
                                                <h5></h5>
                                                <button name="removeCategory" class="btn btn-primary-cancel mx-2" style="position: relative; font-size: 18px; padding: 3px 42px; bottom: 10px;">Șterge</button>
                                                <input type="hidden" name="catId" value="'.$catId. '">
                                            </form></div>
                                        </td>
                                    </tr>';
                            }
                        ?> 
                        </tbody>
                    </table>
                    </div>
                </div>
            </div>
            <!-- Table Panel -->
        </div>
    </div>	    
</div>


<?php 
    $catsql = "SELECT * FROM `categories`";
    $catResult = mysqli_query($conn, $catsql);
    while($catRow = mysqli_fetch_assoc($catResult)){
        $catId = $catRow['categorieId'];
        $catName = $catRow['categorieName'];
        $catDesc = $catRow['categorieDesc'];
?>

<!-- Modal -->
<div class="modal fade" id="updateCat<?php echo $catId; ?>" tabindex="-1" role="dialog" aria-labelledby="updateCat<?php echo $catId; ?>" aria-hidden="true" style="width: -webkit-fill-available;">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header" style="background-color: rgb(111 202 203);">
        <h5 class="modal-title" id="updateCat<?php echo $catId; ?>">ID Categorie: <b><?php echo $catId; ?></b></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="partials/_categoryManage.php" method="post" enctype="multipart/form-data">
		    <div class="text-left my-2 row" style="border-bottom: 2px solid #dee2e6;">
		   		<div class="form-group col-md-8">
					<b><label for="image">Imagine:</label></b>
					<input type="file" name="catimage" id="catimage" accept=".jpg" class="form-control" required style="border:none;" onchange="document.getElementById('itemPhoto').src = window.URL.createObjectURL(this.files[0])">
					<small id="Info" class="form-text text-muted mx-3">A se încărca un fișier .jpg!</small>
					<input type="hidden" id="catId" name="catId" value="<?php echo $catId; ?>">
					<button type="submit" class="btn btn-primary mx-2" name="updateCatPhoto">Actualizare imagine</button>
				</div>
				<div class="form-group col-md-4">
					<img src="/xMAG/img/card-<?php echo $catId; ?>.jpg" id="itemPhoto" name="itemPhoto" alt="Category image" width="100" height="100">
				</div>
			</div>
		</form>
        <form action="partials/_categoryManage.php" method="post">
            <div class="text-left my-2">
                <b><label for="name">Nume: </label></b>
                <input class="form-control" id="name" name="name" value="<?php echo $catName; ?>" type="text" required>
            </div>
            <div class="text-left my-2">
                <b><label for="desc">Descriere: </label></b>
                <textarea class="form-control" id="desc" name="desc" rows="2" required minlength="6"><?php echo $catDesc; ?></textarea>
            </div>
            <input type="hidden" id="catId" name="catId" value="<?php echo $catId; ?>">
            <button type="submit" class="btn btn-primary mx-2" name="updateCategory">Actualizează categorie</button>
        </form>
      </div>
    </div>
  </div>
</div>

<?php
    }
?>
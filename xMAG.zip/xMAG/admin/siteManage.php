<?php
                    $sql = "SELECT * FROM `sitedetail`";
                    $result = mysqli_query($conn, $sql);
                    $row = mysqli_fetch_assoc($result);

                    $systemName = $row['systemName'];
                    $address = $row['address'];
                    $email = $row['email'];
                    $contact1 = $row['contact1'];
                    $contact2 = $row['contact2'];

echo '<div class="container-fluid" style="padding-left: 470px;margin-top:98px">
	<div class="card col-lg-6 p-0">
        <div class="title" style="background-color: rgb(111 202 203);">
            <h2 class="text-center" style="margin-top: 11px; font-family: Bahnschrift;"><b>' .$systemName. '</b></h2>
        </div>
		<div class="card-body">
			<form action="partials/_siteManage.php" method="post">
                <div class="form-group">
                    <label for="name" class="control-label">Nume site web</label>
                    <input type="text" class="form-control" id="name" name="name" value="' .$systemName. '" required>
                </div>
                <div class="form-group">
                    <label for="email" class="control-label">Adresa de email</label>
                    <input type="email" class="form-control" id="email" name="email" value="' .$email. '" required>
                </div>
                <div class="form-group">
                    <label for="contact" class="control-label">Telefon</label>
                    <input type="tel" class="form-control" id="contact1" name="contact1" value="' .$contact1. '" required>
                </div>
                <div class="form-group">
                    <label for="contact" class="control-label">Fax</label>
                    <input type="tel" class="form-control" id="contact2" name="contact2" value="' .$contact2. '" required>
                </div>
                <div class="form-group">
                    <label for="address" class="control-label">Adresa</label>
                    <input type="text" class="form-control" id="address" name="address" value="' .$address. '" required>
                </div>
                <center>
                    <button name="updateDetail" class="btn btn-primary mx-2">Salvare</button>
                </center>
            </form>
		</div>
	</div>';
    
?>

<style>
    *{
        font-family: Bahnschrift;
    }

    .btn-primary {
        background: linear-gradient(to right, #2ae0c4 0%, #1bbca3 100%);
        border-style: none;
        box-shadow: 5px 10px;
    }

    .btn-primary:hover {
        background: linear-gradient(to right, #1bbca3 0%, #334240 100%);
        border-style: none;
        box-shadow: 5px 10px;
    }
</style>
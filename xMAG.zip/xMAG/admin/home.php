<h2 style="margin-top:98px">Bine ai venit <b><?php echo $_SESSION['adminusername']; ?></b>, iată cele mai recente actualizări ale paginii tale: </h2>

<section class="dashboard">

   <h1 class="title"><strong>Pagina de bord</strong></h1>

   <div class="box-container">
            <div class="box">
                <?php 
                    $select_orders = mysqli_query($conn, "SELECT * FROM `orders` WHERE orderStatus = '0'") or die('query failed');
                    $number_of_orders = mysqli_num_rows($select_orders);
                ?>
                <h3><?php echo $number_of_orders; ?></h3>
                <p>COMENZI PLASATE</p>
            </div>

            <div class="box">
                <?php 
                    $select_orders = mysqli_query($conn, "SELECT * FROM `orders` WHERE orderStatus = '4'") or die('query failed');
                    $number_of_orders = mysqli_num_rows($select_orders);
                ?>
                <h3><?php echo $number_of_orders; ?></h3>
                <p>COMENZI EXPEDIATE</p>
            </div>
            
            <div class="box">
                <?php 
                    $select_categories = mysqli_query($conn, "SELECT * FROM `categories`") or die('query failed');
                    $number_of_categories = mysqli_num_rows($select_categories);
                ?>
                <h3><?php echo $number_of_categories; ?></h3>
                <p>BRAND-URI</p>
            </div>  


            <div class="box">
                <?php 
                    $select_products = mysqli_query($conn, "SELECT * FROM `phone`") or die('query failed');
                    $number_of_products = mysqli_num_rows($select_products);
                ?>
                <h3><?php echo $number_of_products; ?></h3>
                <p>PRODUSE</p>
            </div>

            <div class="box">
                <?php 
                    $select_users = mysqli_query($conn, "SELECT * FROM `users` WHERE usertype = '0'") or die('query failed');
                    $number_of_users = mysqli_num_rows($select_users);
                ?>
                <h3><?php echo $number_of_users; ?></h3>
                <p>UTILIZATORI</p>
            </div>

            <div class="box">
                <?php 
                    $select_admins = mysqli_query($conn, "SELECT * FROM `users` WHERE usertype = '1'") or die('query failed');
                    $number_of_admins = mysqli_num_rows($select_admins);
                ?>
                <h3><?php echo $number_of_admins; ?></h3>
                <p>ADMINISTRATORI</p>
            </div>

            <div class="box">
                <?php 
                    $select_account = mysqli_query($conn, "SELECT * FROM `users`") or die('query failed');
                    $number_of_account = mysqli_num_rows($select_account);
                ?>
                <h3><?php echo $number_of_account; ?></h3>
                <p>TOTAL CONTURI</p>
            </div>

            <div class="box">
                <?php 
                    $select_messages = mysqli_query($conn, "SELECT * FROM `contact`") or die('query failed');
                    $number_of_messages = mysqli_num_rows($select_messages);
                ?>
                <h3><?php echo $number_of_messages; ?></h3>
                <p>MESAJE PRIMITE</p>
            </div>

            <div class="box">
                <?php 
                    $select_messages = mysqli_query($conn, "SELECT * FROM `contactreply`") or die('query failed');
                    $number_of_messages = mysqli_num_rows($select_messages);
                ?>
                <h3><?php echo $number_of_messages; ?></h3>
                <p>MESAJE TRIMISE</p>
            </div>
    </div>

</section>

<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<style>
*{
        font-family: Bahnschrift;
}

section{
   padding:3rem 2rem;
}

.title{
   text-align: center;
   margin-bottom: 2rem;
   text-transform: uppercase;
   color:#171427;
   font-size: 3rem;
}

.dashboard .box-container{
   display: grid;
   grid-template-columns: repeat(auto-fit, minmax(12rem, 1fr));
   gap:1.2rem;
   max-width: 800px;
   margin:0 auto;
   align-items: center;
   
}

.dashboard .box-container .box{
   border-radius: .5rem;
   padding:3rem;
   background-color: #fff;
   box-shadow: #1bbca3;
   border:#1bbca3;
   text-align: center;
}

.dashboard .box-container .box h3{
   font-size: 4rem;
   color:#1bbca3; 
   
}

.dashboard .box-container .box p{
   margin-top: 2rem;
   

   background-color: #fff;
   color:#171427;
   font-size: 1rem;
   border:#1bbca3;
}

</style>

<script>
$(document).ready(function(){
  $('[data-toggle="tooltip"]').tooltip();
});
</script>
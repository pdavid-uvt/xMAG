<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
    <title>Produse între 1000 RON și 1999 RON</title>
    <link rel = "icon" href ="img/xmag_icon.png" type = "image/x-icon">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">

    <!-- Vendor CSS Files -->
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
    <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">

    <!-- Template Main CSS File -->
    <link href="assets/css/style6.css" rel="stylesheet">
    <style>
    body {
        background-color: #EFFFFF;
    }
    
    .btn-primary {
        background: linear-gradient(to right, #2ae0c4 0%, #1bbca3 100%);
        border-style: none;
        box-shadow: 5px 10px;
    }

    .btn-primary:hover {
        background: linear-gradient(to right, #1bbca3 0%, #334240 100%);
        border-style: none;
        box-shadow: 5px 10px;
    }

    </style>
  </head>
<body>
  <?php include 'partials/_dbconnect.php';?>
  <?php require 'partials/_nav.php' ?>

    <!-- phone container starts here -->
    <div class="container my-3" id="cont">
            <h5><em>&emsp;</em></h5>      
            <h2 class="text-center"><span id="catTitle"><b>Produse între 1000 RON și 1999 RON</b></span></h2>
            <h5><em>&emsp;</em></h5> 
        <div class="row">
        <?php
            $sql = "SELECT * FROM `phone` where phonePrice between '1000' and '1999' order by phonePrice asc";
            $result = mysqli_query($conn, $sql);
            $noResult = true;
            $noStock = true;
            while($row = mysqli_fetch_assoc($result)){
                $noResult = false;
                $phoneId = $row['phoneId'];
                $phoneStock = $row['phoneStock'];
                $phoneName = $row['phoneName'];
                $phonePrice = $row['phonePrice'];
                $phoneModel = $row['phoneModel'];
                $phoneSIM = $row['phoneSIM'];
                $phoneDisplay = $row['phoneDisplay'];
                $phoneDisplayRes = $row['phoneDisplayRes'];
                $phoneStorage = $row['phoneStorage'];
                $phoneStorageRAM = $row['phoneStorageRAM'];
                $phoneCPUType = $row['phoneCPUType'];
                $phoneCPU = $row['phoneCPU'];
                $phoneCPUHz = $row['phoneCPUHz'];
                $phoneCameraPrincip = $row['phoneCameraPrincip'];
                $phoneCameraRes = $row['phoneCameraRes'];
                $phoneCameraSelfie = $row['phoneCameraSelfie'];
                $phoneBatteryFC = $row['phoneBatteryFC'];
                $phoneBatteryWC = $row['phoneBatteryWC'];
                $phoneBatteryCap = $row['phoneBatteryCap'];
                $phoneOther = $row['phoneOther'];
                $phoneOtherColor = $row['phoneOtherColor'];
                $phoneOtherWeight = $row['phoneOtherWeight'];
                $phoneQuaranty = $row['phoneQuaranty'];

                
                if($phoneStock == 0) {
                    echo '<div class="col-xs-3 col-sm-3 col-md-3">
                        <div class="card" style="width: 17.2rem; height: 38rem;">
                                <div class="card" style="background-color:  #C71585; color: white;" <strong><b>&#8193 SMARTPHONE </b></strong></div>
                                <a href="viewPhone.php?phoneid=' . $phoneId . '"><img src="img/phone-'.$phoneId. '.jpg" class="card-img-top" alt="Imagine pentru produs" style="object-fit: contain; width:100%; padding: 5px 30px; height:100%;"></a> 
                            <div class="card-body">
                                <a href="viewPhone.php?phoneid=' . $phoneId . '"><h5 class="card-title" style="color: #141d28"><strong>' . $phoneName . '</strong></h5></a> 
                                <h3 style="color: #1bbca3"><strong> '.$phonePrice. ' RON</strong></h3>
                                <h6 style="color: #ff0000"><i class="fas fa-store-slash"></i><b> Stoc epuizat</b></h6> 
                                <div class="row justify-content-center">';

                        echo '</form>                            
                        <button disabled class="btn btn-primary mx-2" style="position: absolute; font-size: 20px; padding: 3px 25px; bottom: 10px;" data-toggle="modal" data-target="#loginModal">Disponibil în curând  <i class="fas fa-stopwatch"></i></button>
                            </div>
                        </div>
                    </div>
                    <h5><em>&emsp;</em></h5> 
                </div>';
                }

                else {

                echo '<div class="col-xs-3 col-sm-3 col-md-3">
                        <div class="card" style="width: 17.2rem; height: 38rem;">
                                <div class="card" style="background-color:  #C71585; color: white;" <strong><b>&#8193 SMARTPHONE </b></strong></div>
                                <p><a href="viewPhone.php?phoneid=' . $phoneId . '"><img src="img/phone-'.$phoneId. '.jpg" class="card-img-top" alt="Imagine pentru produs" style="object-fit: contain; width:100%; padding: 5px 30px; height:100%;"></a> </p>
                            <div class="card-body">
                                <a href="viewPhone.php?phoneid=' . $phoneId . '"><h5 class="card-title" style="color: #141d28"><strong>' . $phoneName . '</strong></h5></a> 
                                <h3 style="color: #1bbca3"><strong> '.$phonePrice. ' RON</strong></h3>
                                <h6 style="color: #4CBB17"><i class="fas fa-store"></i><b> În stoc</b></h6> 
                                <div class="row justify-content">';
                

                                if($loggedin){
                                    $quaSql = "SELECT `itemQuantity` FROM `viewcart` WHERE phoneId = '$phoneId' AND `userId`='$userId'";
                                    $quaresult = mysqli_query($conn, $quaSql);
                                    $quaExistRows = mysqli_num_rows($quaresult);
                                    if($quaExistRows == 0) {
                                        echo '<form action="partials/_manageCart.php" method="POST">
                                              <input type="hidden" name="itemId" value="'.$phoneId. '">
                                              <button type="submit" name="addToCart" class="btn btn-primary mx-2" style="position: absolute; font-size: 20px; padding: 3px 50px; bottom: 10px;">Adaugă în coș <i class="fas fa-shopping-bag"></i></button>';
                                    }else {
                                        echo '<a href="viewCart.php"><button class="btn btn-primary mx-2" style="position: absolute; font-size: 20px; padding: 3px 65px; bottom: 10px;">Vezi coșul <i class="fas fa-shopping-basket"></i></button></a>';
                                    }
                                }
                                else{
                                    echo '<button class="btn btn-primary mx-2" style="position: absolute; font-size: 20px; padding: 3px 50px; bottom: 10px;" data-toggle="modal" data-target="#loginModal">Adaugă în coș <i class="fas fa-shopping-bag"></i></button>';
                                }
                            echo '</form>                            
                                </div>
                            </div>
                        </div>
                        <h5><em>&emsp;</em></h5> 
                    </div>';
                            }
            }
            ?>
        </div>
    </div>

    <?php require 'partials/_footer.php' ?>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>         
    <script src="https://unpkg.com/bootstrap-show-password@1.2.1/dist/bootstrap-show-password.min.js"></script>
</body>
</html>
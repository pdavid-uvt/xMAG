<head>
    <link rel="stylesheet" href="/xMAG/assets/css/style6.css">
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
</head>

<style>
    *{
        font-family: Bahnschrift;
    }

</style>

<div class="footer container-fluid">
      <div class="container">
        <div class="row">
          <div class="footer-col">
            <h4><b>BRAND-URI xMAG</b></h4>
            <ul>
            <?php 
              $sql = "SELECT categorieName, categorieId FROM `categories`"; 
            $result = mysqli_query($conn, $sql);
            while($row = mysqli_fetch_assoc($result)){
              echo '<li><a href="viewPhoneList.php?catid=' .$row['categorieId']. '">' .$row['categorieName']. '</a></li>';
            }
              
              ?>
            </ul>
          </div>
          <div class="footer-col">
            <h4><b>FILTRE PRODUSE xMAG</b></h4>
            <ul>
              <li><a href="filter_all.php?phoneid=' . $phoneId . '">Toate produsele</a></li>
              <li><a href="filter_price_x.php?phoneid=' . $phoneId . '">Până la 999 RON</a></li>
              <li><a href="filter_price_t.php?phoneid=' . $phoneId . '">Între 1000 RON și 1999 RON</a></li>
              <li><a href="filter_price_u.php?phoneid=' . $phoneId . '">Între 2000 RON și 2999 RON</a></li>
              <li><a href="filter_price_v.php?phoneid=' . $phoneId . '">Între 3000 RON și 3999 RON</a></li>
              <li><a href="filter_price_y.php?phoneid=' . $phoneId . '">Peste 4000 RON</a></li>
            </ul>
          </div>
          <div class="footer-col">
            <h4><b>CONTACTEAZĂ-NE</b></h4>
            <ul>
            <?php
                    $sql = "SELECT * FROM `sitedetail`";
                    $result = mysqli_query($conn, $sql);
                    $row = mysqli_fetch_assoc($result);

                    $systemName = $row['systemName'];
                    $address = $row['address'];
                    $email = $row['email'];
                    $contact1 = $row['contact1'];
                    $contact2 = $row['contact2'];

                    echo '
                          <li><a href="#">Telefon: 0' .$contact1. '</a></li>
                          <li><a href="#">Fax: 0' .$contact2. '</a></li>
                          <li><a href="contact.php">Lasă-ne un mesaj!</a></li>';
                  ?>
            </ul>
          </div>
          <div class="footer-col">
            <h4><b>URMĂREȘTE-NE</b></h4>
            <div class="social-links">
              <a href="#"><i class="fab fa-facebook-f"></i></a>
              <a href="#"><i class="fab fa-twitter"></i></a>
              <a href="#"><i class="fab fa-instagram"></i></a>
              <a href="#"><i class="fab fa-linkedin-in"></i></a>
            </div>
          </div>
        </div>
      </div>
</div>
